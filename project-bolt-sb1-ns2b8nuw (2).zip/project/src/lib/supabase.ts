import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase credentials are missing');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Profile {
  id: string;
  code: string;
  name: string;
  image_url: string | null;
  stock1: number;
  stock2: number;
  kg_per_meter: number;
  profile_type: number;
  created_at: string;
  updated_at: string;
}

export interface Accessory {
  id: string;
  code: string;
  name: string;
  image_url: string | null;
  unit_price: number;
  created_at: string;
  updated_at: string;
}
