export interface User {
  id: string;
  email: string;
}

export interface UserProfile {
  id: string;
  full_name: string;
  company_name?: string;
  phone?: string;
  is_admin: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProfileType {
  id: string;
  name: string;
  price_per_kg: number;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface PanelType {
  id: string;
  name: string;
  price_per_m2: number;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface VerandaConfig {
  width: number;
  depth: number;
  backHeight: number;
  slope: number;
  divisions: number;
  legs: number;
  profileTypeId: string;
  panelTypeId: string;
  glassPartitions?: number;
}

export interface Material {
  code: string;
  name: string;
  imageUrl?: string | null;
  length: number;
  quantity: number;
  kgPerMeter: number;
  stockBars: number;
  stockLength: number;
  totalMeters: number;
  totalKg: number;
  totalPrice: number;
  stockTotalMeters: number;
  stockTotalPrice: number;
}

export interface Accessory {
  code: string;
  name: string;
  imageUrl?: string | null;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export interface CalculationResult {
  frontHeight: number;
  hipLength: number;
  legHeight: number;
  materials: Material[];
  accessories: Accessory[];
  totalMaterialCost: number;
  totalAccessoryCost: number;
  panelArea?: number;
  panelCost?: number;
  panelWidth?: number;
  panelDepth?: number;
  panelCount?: number;
  subtotal: number;
  vat: number;
  grandTotal: number;
  totalKg?: number;
  footCount?: number;
}
