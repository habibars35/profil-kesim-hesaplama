import { VerandaConfig, CalculationResult, Material, Accessory } from '../types';
import { supabase, Profile, Accessory as DBAccessory } from '../lib/supabase';

interface OptimalStock {
  bars: number;
  stockLength: number;
  totalMeters: number;
}

function getOptimalStock(
  pieceLength: number,
  quantity: number,
  stock1: number,
  stock2: number
): OptimalStock {
  const options = [stock1, stock2];
  let best: OptimalStock = {
    bars: 0,
    stockLength: 0,
    totalMeters: Infinity,
  };

  if (pieceLength > Math.max(...options)) {
    const halfLength = pieceLength / 2;
    const subResult = getOptimalStock(halfLength, quantity * 2, stock1, stock2);
    return subResult;
  }

  options.forEach((stockLength) => {
    if (stockLength < pieceLength) return;
    const piecesPerBar = Math.floor(stockLength / pieceLength);
    const bars = Math.ceil(quantity / piecesPerBar);
    const totalMeters = (bars * stockLength) / 1000;
    if (totalMeters < best.totalMeters) {
      best = { bars, stockLength, totalMeters };
    }
  });

  return best;
}

export const calculateVeranda = async (
  config: VerandaConfig
): Promise<CalculationResult> => {
  const { width, depth, backHeight, slope, divisions, legs, profileTypeId, panelTypeId } = config;

  // Fetch calculation variables from database
  const { data: variables } = await supabase
    .from('calculation_variables')
    .select('*');

  const variableMap = new Map<string, number>();
  variables?.forEach((v) => variableMap.set(v.variable_name, v.value));

  // Get all variables from database (with fallback defaults)
  const kayitGenisligi = variableMap.get('kayit_genisligi') || 61;
  const profilBinmePayi = variableMap.get('profil_binme_payi') || 35;
  const uzunlukPayi = variableMap.get('uzunluk_payi') || 30;
  const kayitProfilPayi = variableMap.get('kayit_profil_payi') || 155;
  const panelUzunlukPayi = variableMap.get('panel_uzunluk_payi') || 30;
  const bacakAsagiPayi = variableMap.get('bacak_asagi_payi') || 180;
  const kdvOrani = variableMap.get('kdv_orani') || 0.20;
  const fitMeterCarpani = variableMap.get('fit_meter_carpani') || 1000;
  const kayitFitCarpani = variableMap.get('kayit_fit_carpani') || 2;
  const duvarKapagiAdet = variableMap.get('duvar_kapagi_adet') || 2;
  const olukKapagiAdet = variableMap.get('oluk_kapagi_adet') || 2;

  const slopeDiff = depth * (slope / 100);
  const frontHeight = backHeight - slopeDiff;
  const hipLength = Math.sqrt(depth * depth + slopeDiff * slopeDiff);
  const legHeight = Math.round(backHeight - slopeDiff - bacakAsagiPayi);

  // L705 kayıt profil boyu = hipotenüs - kayıt profil payı
  const kayitLength = Math.round(hipLength - kayitProfilPayi);

  // Vuar/Oluk kapak ölçüsü = (genişlik - (kayıt genişliği * (bölme+1))) / bölme sayısı
  const kapatmaLength = Math.round((width - (kayitGenisligi * (divisions + 1))) / divisions);

  const [
    { data: profiles },
    { data: accessories },
    { data: profileType },
    { data: panelType }
  ] = await Promise.all([
    supabase.from('profiles').select('*').order('code'),
    supabase.from('accessories').select('*').order('code'),
    supabase.from('profile_types').select('*').eq('id', profileTypeId).maybeSingle(),
    supabase.from('panel_types').select('*').eq('id', panelTypeId).maybeSingle()
  ]);

  const profileMap = new Map<string, Profile>();
  profiles?.forEach((p) => profileMap.set(p.code, p));

  const accessoryMap = new Map<string, DBAccessory>();
  accessories?.forEach((a) => accessoryMap.set(a.code, a));

  const materialConfigs = [
    { code: 'L701', length: width, quantity: 1 },
    { code: 'L702', length: width, quantity: 1 },
    { code: 'L703', length: legHeight, quantity: legs },
    { code: 'L704', length: legHeight, quantity: legs },
    { code: 'L705', length: kayitLength, quantity: divisions + 1 },
    { code: 'L706', length: kayitLength, quantity: 2 },
    { code: 'L707', length: kayitLength, quantity: Math.max(0, divisions - 1) },
    { code: 'L709', length: kapatmaLength, quantity: divisions * 2 },
  ];

  const pricePerKg = profileType?.price_per_kg || 0;

  const materials: Material[] = materialConfigs.map((config) => {
    const profile = profileMap.get(config.code);
    if (!profile) {
      return {
        code: config.code,
        name: 'Bilinmeyen Profil',
        length: config.length,
        quantity: config.quantity,
        kgPerMeter: 0,
        stockBars: 0,
        stockLength: 0,
        totalMeters: 0,
        totalKg: 0,
        totalPrice: 0,
        stockTotalMeters: 0,
        stockTotalPrice: 0,
      };
    }

    const optimal = getOptimalStock(
      config.length,
      config.quantity,
      profile.stock1,
      profile.stock2
    );

    const actualMeters = (config.length * config.quantity) / 1000;
    const totalKg = actualMeters * profile.kg_per_meter;
    const totalPrice = totalKg * pricePerKg;

    const stockTotalMeters = optimal.totalMeters;
    const stockTotalKg = stockTotalMeters * profile.kg_per_meter;
    const stockTotalPrice = stockTotalKg * pricePerKg;

    return {
      code: profile.code,
      name: profile.name,
      imageUrl: profile.image_url,
      length: config.length,
      quantity: config.quantity,
      kgPerMeter: profile.kg_per_meter,
      stockBars: optimal.bars,
      stockLength: optimal.stockLength,
      totalMeters: actualMeters,
      totalKg,
      totalPrice,
      stockTotalMeters,
      stockTotalPrice,
    };
  });

  const totalMaterialCost = materials.reduce((sum, m) => sum + m.totalPrice, 0);

  // Panel dimensions based on calculated kapatmaLength and kayitLength
  const panelWidth = kapatmaLength + profilBinmePayi;
  const panelDepth = kayitLength + panelUzunlukPayi;
  const panelArea = (panelWidth / 1000) * (panelDepth / 1000) * divisions;
  const panelPricePerM2 = panelType?.price_per_m2 || 0;
  const panelCost = panelArea * panelPricePerM2;

  const accessoryConfigs = [
    { code: 'K-DUV', quantity: duvarKapagiAdet },
    { code: 'K-OLU', quantity: olukKapagiAdet },
    { code: 'F-FLN', quantity: legs },
    { code: 'FIT-O', quantity: Math.ceil(width / fitMeterCarpani) },
    { code: 'FIT-C', quantity: Math.ceil((kayitLength * (divisions + 1) * kayitFitCarpani) / fitMeterCarpani) },
  ];

  const accessoryList: Accessory[] = accessoryConfigs.map((config) => {
    const accessory = accessoryMap.get(config.code);
    if (!accessory) {
      return {
        code: config.code,
        name: 'Bilinmeyen Aksesuar',
        quantity: config.quantity,
        unitPrice: 0,
        totalPrice: 0,
      };
    }

    return {
      code: accessory.code,
      name: accessory.name,
      imageUrl: accessory.image_url,
      quantity: config.quantity,
      unitPrice: accessory.unit_price,
      totalPrice: config.quantity * accessory.unit_price,
    };
  });

  const totalAccessoryCost = accessoryList.reduce(
    (sum, a) => sum + a.totalPrice,
    0
  );
  const subtotal = totalMaterialCost + totalAccessoryCost + panelCost;
  const vat = subtotal * kdvOrani;
  const grandTotal = subtotal + vat;

  const totalKg = materials.reduce((sum, m) => sum + m.totalKg, 0);
  const footCount = legs;

  return {
    frontHeight,
    hipLength,
    legHeight,
    materials,
    accessories: accessoryList,
    totalMaterialCost,
    totalAccessoryCost,
    subtotal,
    vat,
    grandTotal,
    panelArea,
    panelCost,
    panelWidth,
    panelDepth,
    panelCount: divisions,
    totalKg,
    footCount,
  };
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
  }).format(amount);
};

export const formatNumber = (num: number, decimals: number = 2): string => {
  return num.toFixed(decimals);
};
