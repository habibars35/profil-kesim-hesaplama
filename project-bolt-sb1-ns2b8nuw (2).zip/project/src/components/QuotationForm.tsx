import { useState } from 'react';
import { CalculationResult, VerandaConfig } from '../types';
import { formatCurrency, formatNumber } from '../utils/calculations';
import { Printer, Download } from 'lucide-react';
import DrawingView from './DrawingView';
import { generatePDF } from '../utils/pdfExport';

interface QuotationFormProps {
  result: CalculationResult;
  config: VerandaConfig;
  profileTypeName?: string;
  panelTypeName?: string;
}

export const QuotationForm = ({ result, config, profileTypeName, panelTypeName }: QuotationFormProps) => {
  const [profitMargin, setProfitMargin] = useState<number>(25);
  const [quotationPrice, setQuotationPrice] = useState<number>(() => {
    const markup = 1 + profitMargin / 100;
    return result.subtotal * markup;
  });
  const [notes, setNotes] = useState<string>('');

  const updateProfitMargin = (newMargin: number) => {
    setProfitMargin(newMargin);
    const markup = 1 + newMargin / 100;
    setQuotationPrice(result.subtotal * markup);
  };

  const quotationVAT = quotationPrice * 0.2;
  const quotationTotal = quotationPrice + quotationVAT;
  const totalProfit = quotationPrice - result.subtotal;
  const actualMargin = result.subtotal > 0 ? (totalProfit / result.subtotal) * 100 : 0;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    try {
      await generatePDF('quotation-content', `fiyat-teklifi-${new Date().toLocaleDateString('tr-TR')}.pdf`);
    } catch (error) {
      console.error('PDF oluşturma hatası:', error);
      alert('PDF oluşturulurken bir hata oluştu.');
    }
  };

  return (
    <div className="space-y-6">
      {/* PDF İndirme ve Yazdırma Butonları - EN ÜSTTE */}
      <div className="print:hidden bg-gradient-to-r from-green-50 to-blue-50 p-3 sm:p-4 rounded-lg shadow-lg border border-green-200">
        <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-3">
          <button
            onClick={handleDownloadPDF}
            className="flex items-center justify-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 active:bg-green-800 transition-all shadow-md hover:shadow-lg font-semibold text-sm sm:text-base w-full sm:w-auto"
          >
            <Download className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>PDF İndir</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center justify-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 bg-gray-800 text-white rounded-lg hover:bg-gray-900 active:bg-gray-950 transition-all shadow-md hover:shadow-lg font-semibold text-sm sm:text-base w-full sm:w-auto"
          >
            <Printer className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>Yazdır</span>
          </button>
        </div>
      </div>

      {/* Kar Marjı Ayarları - Sadece ekranda görünür */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 print:hidden">
        <div className="mb-4">
          <h3 className="text-lg font-semibold text-blue-900">Kar Marjı Ayarları</h3>
        </div>

        {/* Maliyet Dökümü */}
        <div className="bg-white rounded-lg p-4 mb-4">
          <h4 className="text-sm font-semibold text-gray-700 mb-3">Maliyet Dökümü</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Profil Maliyeti:</span>
              <span className="font-semibold text-gray-900">
                {formatCurrency(result.totalMaterialCost)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Panel Maliyeti:</span>
              <span className="font-semibold text-gray-900">
                {formatCurrency(result.panelCost)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Aksesuar Maliyeti:</span>
              <span className="font-semibold text-gray-900">
                {formatCurrency(result.totalAccessoryCost)}
              </span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-gray-200">
              <span className="text-gray-700 font-medium">Toplam Maliyet (KDV Hariç):</span>
              <span className="font-bold text-gray-900">
                {formatCurrency(result.subtotal)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">KDV (%20):</span>
              <span className="font-semibold text-gray-900">
                {formatCurrency(result.vat)}
              </span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-gray-200">
              <span className="text-gray-700 font-medium">Net Maliyet:</span>
              <span className="font-bold text-red-600">
                {formatCurrency(result.grandTotal)}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Kar Marjı (%)
              </label>
              <input
                type="number"
                value={profitMargin}
                onChange={(e) => updateProfitMargin(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                min="0"
                step="1"
              />
            </div>
            <div className="flex flex-col justify-end">
              <span className="text-sm text-gray-600">Toplam Kar:</span>
              <span className="text-lg font-bold text-green-600">
                {formatCurrency(totalProfit)}
              </span>
            </div>
            <div className="flex flex-col justify-end">
              <span className="text-sm text-gray-600">Gerçek Kar Marjı:</span>
              <span className="text-lg font-bold text-green-600">
                %{formatNumber(actualMargin, 1)}
              </span>
            </div>
          </div>
          <div className="pt-3 border-t border-gray-200">
            <div className="flex justify-between items-center">
              <span className="text-gray-700 font-medium">Teklif Tutarı (KDV Hariç):</span>
              <span className="text-xl font-bold text-blue-600">
                {formatCurrency(quotationPrice)}
              </span>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-gray-700 font-medium">KDV:</span>
              <span className="text-xl font-bold text-gray-700">
                {formatCurrency(quotationVAT)}
              </span>
            </div>
            <div className="flex justify-between items-center mt-2 pt-2 border-t">
              <span className="text-gray-900 font-bold">Genel Toplam:</span>
              <span className="text-2xl font-bold text-blue-700">
                {formatCurrency(quotationTotal)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Teklif Formu */}
      <div id="quotation-content" className="bg-white rounded-lg shadow-lg p-3 print:shadow-none print:p-2">
        {/* Başlık */}
        <div className="text-center mb-2 border-b pb-2">
          <h1 className="text-xl font-bold text-gray-800 mb-0.5">FİYAT TEKLİFİ</h1>
          <p className="text-xs text-gray-600">LOCKWIN Cam Balkon Sistemleri</p>
          <p className="text-xs text-gray-500">Tarih: {new Date().toLocaleDateString('tr-TR')}</p>
        </div>

        {/* Sistem Özellikleri */}
        <section className="mb-2">
          <h2 className="text-sm font-semibold text-gray-800 mb-1">Sistem Özellikleri</h2>
          <div className="bg-gray-50 rounded p-2">
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              <div>
                <span className="text-gray-600">Cephe Genişlik:</span>
                <span className="ml-1 font-medium text-gray-900">{config.width} mm</span>
              </div>
              <div>
                <span className="text-gray-600">Derinlik:</span>
                <span className="ml-1 font-medium text-gray-900">{config.depth} mm</span>
              </div>
              <div>
                <span className="text-gray-600">Arka Yükseklik:</span>
                <span className="ml-1 font-medium text-gray-900">{config.backHeight} mm</span>
              </div>
              <div>
                <span className="text-gray-600">Ön Yükseklik:</span>
                <span className="ml-1 font-medium text-gray-900">
                  {formatNumber(result.frontHeight)} mm
                </span>
              </div>
              <div>
                <span className="text-gray-600">Eğim:</span>
                <span className="ml-1 font-medium text-gray-900">%{config.slope}</span>
              </div>
              <div>
                <span className="text-gray-600">Cam Bölme:</span>
                <span className="ml-1 font-medium text-gray-900">{config.divisions}</span>
              </div>
              <div>
                <span className="text-gray-600">Ayak Sayısı:</span>
                <span className="ml-1 font-medium text-gray-900">{config.legs}</span>
              </div>
              <div>
                <span className="text-gray-600">Panel:</span>
                <span className="ml-1 font-medium text-gray-900">
                  {formatNumber(result.panelWidth)} x {formatNumber(result.panelDepth)} mm
                </span>
              </div>
              {profileTypeName && (
                <div>
                  <span className="text-gray-600">Profil Rengi:</span>
                  <span className="ml-1 font-medium text-gray-900">{profileTypeName}</span>
                </div>
              )}
              {panelTypeName && (
                <div>
                  <span className="text-gray-600">Panel Tipi:</span>
                  <span className="ml-1 font-medium text-gray-900">{panelTypeName}</span>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Sistem Çizimi */}
        <section className="mb-2">
          <h2 className="text-sm font-semibold text-gray-800 mb-1">Sistem Çizimi</h2>
          <div className="bg-white border border-gray-200 rounded p-1">
            <DrawingView result={result} config={config} />
          </div>
        </section>

        {/* Fiyat Bilgileri */}
        <section className="mb-2">
          <h2 className="text-sm font-semibold text-gray-800 mb-1">Fiyat Bilgileri</h2>
          <div className="bg-gray-50 rounded p-2">
            <div className="space-y-1 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Ara Toplam (KDV Hariç):</span>
                <span className="font-semibold text-gray-900 print:block">
                  <input
                    type="number"
                    value={quotationPrice.toFixed(2)}
                    onChange={(e) => setQuotationPrice(Number(e.target.value))}
                    className="w-28 px-2 py-0.5 text-right text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent print:border-0 print:bg-transparent"
                    step="0.01"
                  />
                </span>
              </div>
              <div className="flex justify-between items-center border-t pt-1">
                <span className="text-gray-700">KDV (%20):</span>
                <span className="font-semibold text-gray-900">{formatCurrency(quotationVAT)}</span>
              </div>
              <div className="flex justify-between items-center text-sm font-bold bg-gray-800 text-white rounded p-2 mt-1">
                <span>Genel Toplam:</span>
                <span>{formatCurrency(quotationTotal)}</span>
              </div>
            </div>
          </div>
        </section>

        {/* Notlar */}
        <section className="mt-2 pt-2 border-t">
          <h3 className="text-xs font-semibold text-gray-700 mb-1">Notlar:</h3>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Buraya özel notlar girebilirsiniz..."
            className="w-full px-2 py-1 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent print:border-0 min-h-[50px] text-xs text-gray-700"
          />
        </section>
      </div>
    </div>
  );
};
