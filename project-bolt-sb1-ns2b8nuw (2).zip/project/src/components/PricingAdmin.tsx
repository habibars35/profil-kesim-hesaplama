import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ProfileType, PanelType } from '../types';
import { Plus, Edit2, Trash2, Save, X } from 'lucide-react';

export function PricingAdmin() {
  const [profileTypes, setProfileTypes] = useState<ProfileType[]>([]);
  const [panelTypes, setPanelTypes] = useState<PanelType[]>([]);
  const [editingProfile, setEditingProfile] = useState<ProfileType | null>(null);
  const [editingPanel, setEditingPanel] = useState<PanelType | null>(null);
  const [newProfile, setNewProfile] = useState({ name: '', price_per_kg: 0, description: '' });
  const [newPanel, setNewPanel] = useState({ name: '', price_per_m2: 0, description: '' });
  const [showNewProfile, setShowNewProfile] = useState(false);
  const [showNewPanel, setShowNewPanel] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [profilesRes, panelsRes] = await Promise.all([
      supabase.from('profile_types').select('*').order('name'),
      supabase.from('panel_types').select('*').order('name'),
    ]);

    if (profilesRes.data) setProfileTypes(profilesRes.data);
    if (panelsRes.data) setPanelTypes(panelsRes.data);
  };

  const handleAddProfile = async () => {
    if (!newProfile.name || newProfile.price_per_kg <= 0) return;

    const { error } = await supabase.from('profile_types').insert([newProfile]);
    if (!error) {
      setNewProfile({ name: '', price_per_kg: 0, description: '' });
      setShowNewProfile(false);
      loadData();
    }
  };

  const handleAddPanel = async () => {
    if (!newPanel.name || newPanel.price_per_m2 <= 0) return;

    const { error } = await supabase.from('panel_types').insert([newPanel]);
    if (!error) {
      setNewPanel({ name: '', price_per_m2: 0, description: '' });
      setShowNewPanel(false);
      loadData();
    }
  };

  const handleUpdateProfile = async () => {
    if (!editingProfile) return;

    const { error } = await supabase
      .from('profile_types')
      .update({
        name: editingProfile.name,
        price_per_kg: editingProfile.price_per_kg,
        description: editingProfile.description,
        is_active: editingProfile.is_active,
      })
      .eq('id', editingProfile.id);

    if (!error) {
      setEditingProfile(null);
      loadData();
    }
  };

  const handleUpdatePanel = async () => {
    if (!editingPanel) return;

    const { error } = await supabase
      .from('panel_types')
      .update({
        name: editingPanel.name,
        price_per_m2: editingPanel.price_per_m2,
        description: editingPanel.description,
        is_active: editingPanel.is_active,
      })
      .eq('id', editingPanel.id);

    if (!error) {
      setEditingPanel(null);
      loadData();
    }
  };

  const handleDeleteProfile = async (id: string) => {
    if (!confirm('Bu profil türünü silmek istediğinize emin misiniz?')) return;
    const { error } = await supabase.from('profile_types').delete().eq('id', id);
    if (!error) loadData();
  };

  const handleDeletePanel = async (id: string) => {
    if (!confirm('Bu panel türünü silmek istediğinize emin misiniz?')) return;
    const { error } = await supabase.from('panel_types').delete().eq('id', id);
    if (!error) loadData();
  };

  return (
    <div className="space-y-8">
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-gray-900">Profil Türleri</h2>
          <button
            onClick={() => setShowNewProfile(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Yeni Profil Ekle
          </button>
        </div>

        {showNewProfile && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <input
                type="text"
                placeholder="Profil Adı"
                value={newProfile.name}
                onChange={(e) => setNewProfile({ ...newProfile, name: e.target.value })}
                className="px-4 py-2 border rounded-lg"
              />
              <input
                type="number"
                placeholder="kg Başı Fiyat (TL)"
                value={newProfile.price_per_kg || ''}
                onChange={(e) => setNewProfile({ ...newProfile, price_per_kg: parseFloat(e.target.value) || 0 })}
                className="px-4 py-2 border rounded-lg"
              />
              <input
                type="text"
                placeholder="Açıklama (opsiyonel)"
                value={newProfile.description}
                onChange={(e) => setNewProfile({ ...newProfile, description: e.target.value })}
                className="px-4 py-2 border rounded-lg"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleAddProfile}
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Kaydet
              </button>
              <button
                onClick={() => setShowNewProfile(false)}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                İptal
              </button>
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Profil Adı</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">kg Başı Fiyat</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Açıklama</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlemler</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {profileTypes.map((profile) => (
                <tr key={profile.id}>
                  {editingProfile?.id === profile.id ? (
                    <>
                      <td className="px-6 py-4">
                        <input
                          type="text"
                          value={editingProfile.name}
                          onChange={(e) => setEditingProfile({ ...editingProfile, name: e.target.value })}
                          className="px-2 py-1 border rounded"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="number"
                          value={editingProfile.price_per_kg}
                          onChange={(e) => setEditingProfile({ ...editingProfile, price_per_kg: parseFloat(e.target.value) })}
                          className="px-2 py-1 border rounded w-32"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="text"
                          value={editingProfile.description || ''}
                          onChange={(e) => setEditingProfile({ ...editingProfile, description: e.target.value })}
                          className="px-2 py-1 border rounded"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={editingProfile.is_active ? 'true' : 'false'}
                          onChange={(e) => setEditingProfile({ ...editingProfile, is_active: e.target.value === 'true' })}
                          className="px-2 py-1 border rounded"
                        >
                          <option value="true">Aktif</option>
                          <option value="false">Pasif</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button onClick={handleUpdateProfile} className="text-green-600 hover:text-green-700">
                            <Save className="w-5 h-5" />
                          </button>
                          <button onClick={() => setEditingProfile(null)} className="text-gray-600 hover:text-gray-700">
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </>
                  ) : (
                    <>
                      <td className="px-6 py-4 whitespace-nowrap font-medium">{profile.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{profile.price_per_kg.toFixed(2)} TL</td>
                      <td className="px-6 py-4">{profile.description || '-'}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${profile.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {profile.is_active ? 'Aktif' : 'Pasif'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex gap-2">
                          <button onClick={() => setEditingProfile(profile)} className="text-blue-600 hover:text-blue-700">
                            <Edit2 className="w-5 h-5" />
                          </button>
                          <button onClick={() => handleDeleteProfile(profile.id)} className="text-red-600 hover:text-red-700">
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-gray-900">Panel Türleri</h2>
          <button
            onClick={() => setShowNewPanel(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Yeni Panel Ekle
          </button>
        </div>

        {showNewPanel && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <input
                type="text"
                placeholder="Panel Adı"
                value={newPanel.name}
                onChange={(e) => setNewPanel({ ...newPanel, name: e.target.value })}
                className="px-4 py-2 border rounded-lg"
              />
              <input
                type="number"
                placeholder="m² Başı Fiyat (TL)"
                value={newPanel.price_per_m2 || ''}
                onChange={(e) => setNewPanel({ ...newPanel, price_per_m2: parseFloat(e.target.value) || 0 })}
                className="px-4 py-2 border rounded-lg"
              />
              <input
                type="text"
                placeholder="Açıklama (opsiyonel)"
                value={newPanel.description}
                onChange={(e) => setNewPanel({ ...newPanel, description: e.target.value })}
                className="px-4 py-2 border rounded-lg"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleAddPanel}
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Kaydet
              </button>
              <button
                onClick={() => setShowNewPanel(false)}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                İptal
              </button>
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Panel Adı</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">m² Başı Fiyat</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Açıklama</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlemler</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {panelTypes.map((panel) => (
                <tr key={panel.id}>
                  {editingPanel?.id === panel.id ? (
                    <>
                      <td className="px-6 py-4">
                        <input
                          type="text"
                          value={editingPanel.name}
                          onChange={(e) => setEditingPanel({ ...editingPanel, name: e.target.value })}
                          className="px-2 py-1 border rounded"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="number"
                          value={editingPanel.price_per_m2}
                          onChange={(e) => setEditingPanel({ ...editingPanel, price_per_m2: parseFloat(e.target.value) })}
                          className="px-2 py-1 border rounded w-32"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="text"
                          value={editingPanel.description || ''}
                          onChange={(e) => setEditingPanel({ ...editingPanel, description: e.target.value })}
                          className="px-2 py-1 border rounded"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={editingPanel.is_active ? 'true' : 'false'}
                          onChange={(e) => setEditingPanel({ ...editingPanel, is_active: e.target.value === 'true' })}
                          className="px-2 py-1 border rounded"
                        >
                          <option value="true">Aktif</option>
                          <option value="false">Pasif</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button onClick={handleUpdatePanel} className="text-green-600 hover:text-green-700">
                            <Save className="w-5 h-5" />
                          </button>
                          <button onClick={() => setEditingPanel(null)} className="text-gray-600 hover:text-gray-700">
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </>
                  ) : (
                    <>
                      <td className="px-6 py-4 whitespace-nowrap font-medium">{panel.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{panel.price_per_m2.toFixed(2)} TL</td>
                      <td className="px-6 py-4">{panel.description || '-'}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${panel.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {panel.is_active ? 'Aktif' : 'Pasif'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex gap-2">
                          <button onClick={() => setEditingPanel(panel)} className="text-blue-600 hover:text-blue-700">
                            <Edit2 className="w-5 h-5" />
                          </button>
                          <button onClick={() => handleDeletePanel(panel.id)} className="text-red-600 hover:text-red-700">
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
