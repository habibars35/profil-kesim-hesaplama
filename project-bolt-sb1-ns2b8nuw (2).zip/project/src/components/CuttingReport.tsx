import { CalculationResult } from '../types';
import { formatNumber } from '../utils/calculations';
import { Printer, Download } from 'lucide-react';
import { generatePDF } from '../utils/pdfExport';

interface CuttingReportProps {
  result: CalculationResult;
  profileTypeName?: string;
}

export const CuttingReport = ({ result, profileTypeName }: CuttingReportProps) => {
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    try {
      await generatePDF('cutting-report-content', `kesim-raporu-${new Date().toLocaleDateString('tr-TR')}.pdf`);
    } catch (error) {
      console.error('PDF oluşturma hatası:', error);
      alert('PDF oluşturulurken bir hata oluştu.');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 print:shadow-none print:p-3">
      <div className="flex justify-between items-center mb-3 pb-2 print:hidden">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Profil Kesim Raporu</h2>
          <p className="text-xs text-gray-600">
            Tarih: {new Date().toLocaleDateString('tr-TR')}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleDownloadPDF}
            className="flex items-center gap-2 px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
          >
            <Download className="w-4 h-4" />
            PDF İndir
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-3 py-1.5 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm"
          >
            <Printer className="w-4 h-4" />
            Yazdır
          </button>
        </div>
      </div>
      <div id="cutting-report-content">

      {profileTypeName && (
        <div className="mb-3 pb-2 border-b">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Profil Rengi:</span> {profileTypeName}
          </p>
        </div>
      )}

      <div className="space-y-2">
        {result.materials.map((material, index) => (
          <div key={index} className="border rounded p-2 text-xs">
            {/* Tek Satır Profil Bilgisi */}
            <div className="flex items-center gap-3 min-h-[20mm]">
              {/* Profil Resmi */}
              {material.imageUrl && (
                <img
                  src={material.imageUrl}
                  alt={material.code}
                  className="w-12 h-12 object-cover rounded border flex-shrink-0"
                />
              )}

              {/* Profil Kodu */}
              <div className="w-20 flex-shrink-0">
                <span className="font-semibold text-gray-900">{material.code}</span>
              </div>

              {/* Açıklama */}
              <div className="flex-1 min-w-0">
                <span className="text-gray-700">{material.name}</span>
              </div>

              {/* Kesim Adedi */}
              <div className="w-16 text-center flex-shrink-0">
                <span className="font-bold text-gray-900">{material.quantity} Adet</span>
              </div>

              {/* Kesim Ölçüsü */}
              <div className="w-24 text-right flex-shrink-0">
                <span className="font-semibold text-blue-900">{material.length} mm</span>
              </div>

              {/* Stok Bilgisi */}
              <div className="w-32 text-right flex-shrink-0">
                <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                  {material.stockBars} Stok ({material.stockLength}mm)
                </span>
              </div>
            </div>
          </div>
        ))}

        {/* Özet */}
        <div className="border-t-2 pt-2 mt-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-2">Kesim Özeti</h3>
          <div className="grid grid-cols-3 gap-3 bg-gray-50 rounded p-2.5">
            <div className="text-center">
              <div className="text-lg font-bold text-gray-900">
                {result.materials.reduce((sum, m) => sum + m.quantity, 0)}
              </div>
              <div className="text-xs text-gray-600">Toplam Kesim</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-gray-900">
                {result.materials.reduce((sum, m) => sum + m.stockBars, 0)}
              </div>
              <div className="text-xs text-gray-600">Toplam Stok</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-gray-900">
                {formatNumber(result.materials.reduce((sum, m) => sum + m.totalKg, 0))}
              </div>
              <div className="text-xs text-gray-600">Toplam kg</div>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};
