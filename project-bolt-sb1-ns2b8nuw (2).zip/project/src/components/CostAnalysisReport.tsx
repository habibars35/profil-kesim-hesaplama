import { CalculationResult } from '../types';
import { formatCurrency, formatNumber } from '../utils/calculations';
import { Download, Printer } from 'lucide-react';
import { generatePDF } from '../utils/pdfExport';

interface CostAnalysisReportProps {
  result: CalculationResult;
}

export const CostAnalysisReport = ({ result }: CostAnalysisReportProps) => {
  const handleDownloadPDF = async () => {
    try {
      await generatePDF('cost-analysis-content', `maliyet-analizi-${new Date().toLocaleDateString('tr-TR')}.pdf`);
    } catch (error) {
      console.error('PDF oluşturma hatası:', error);
      alert('PDF oluşturulurken bir hata oluştu.');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 print:shadow-none">
      <div className="flex justify-between items-center mb-6 border-b pb-3 print:block">
        <h2 className="text-2xl font-bold text-gray-800">
          Malzeme Listesi
        </h2>
        <div className="flex gap-2 print:hidden">
          <button
            onClick={handleDownloadPDF}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
          >
            <Download className="w-4 h-4" />
            PDF İndir
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm"
          >
            <Printer className="w-4 h-4" />
            Yazdır
          </button>
        </div>
      </div>
      <div id="cost-analysis-content">

      <div className="space-y-6">
        {/* Profil Maliyetleri */}
        <section>
          <h3 className="text-lg font-semibold text-gray-700 mb-3">Profil Maliyetleri</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left font-medium text-gray-600">Kod</th>
                  <th className="px-4 py-3 text-left font-medium text-gray-600">Profil Adı</th>
                  <th className="px-4 py-3 text-right font-medium text-gray-600">Adet</th>
                  <th className="px-4 py-3 text-right font-medium text-gray-600">Kesim Uzunluk</th>
                  <th className="px-4 py-3 text-right font-medium text-gray-600">Stok Adet</th>
                  <th className="px-4 py-3 text-right font-medium text-gray-600">Toplam Metre</th>
                  <th className="px-4 py-3 text-right font-medium text-gray-600">Tutar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {result.materials.map((material, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{material.code}</td>
                    <td className="px-4 py-3 text-gray-700">{material.name}</td>
                    <td className="px-4 py-3 text-right text-gray-700">{material.quantity}</td>
                    <td className="px-4 py-3 text-right text-gray-700">{material.length} mm</td>
                    <td className="px-4 py-3 text-right text-gray-700">
                      {material.stockBars} x {material.stockLength}mm
                    </td>
                    <td className="px-4 py-3 text-right text-gray-700">
                      {formatNumber(material.totalMeters)} m
                    </td>
                    <td className="px-4 py-3 text-right font-medium text-gray-900">
                      {formatCurrency(material.totalPrice)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50 font-semibold">
                <tr>
                  <td colSpan={6} className="px-4 py-3 text-right text-gray-700">
                    Profil Toplam:
                  </td>
                  <td className="px-4 py-3 text-right text-gray-900">
                    {formatCurrency(result.totalMaterialCost)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </section>

        {/* Aksesuar Maliyetleri */}
        <section>
          <h3 className="text-lg font-semibold text-gray-700 mb-3">Aksesuar Maliyetleri</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left font-medium text-gray-600">Kod</th>
                  <th className="px-4 py-3 text-left font-medium text-gray-600">Aksesuar Adı</th>
                  <th className="px-4 py-3 text-right font-medium text-gray-600">Adet</th>
                  <th className="px-4 py-3 text-right font-medium text-gray-600">Birim Fiyat</th>
                  <th className="px-4 py-3 text-right font-medium text-gray-600">Tutar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {result.accessories.map((accessory, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{accessory.code}</td>
                    <td className="px-4 py-3 text-gray-700">{accessory.name}</td>
                    <td className="px-4 py-3 text-right text-gray-700">{accessory.quantity}</td>
                    <td className="px-4 py-3 text-right text-gray-700">
                      {formatCurrency(accessory.unitPrice)}
                    </td>
                    <td className="px-4 py-3 text-right font-medium text-gray-900">
                      {formatCurrency(accessory.totalPrice)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50 font-semibold">
                <tr>
                  <td colSpan={4} className="px-4 py-3 text-right text-gray-700">
                    Aksesuar Toplam:
                  </td>
                  <td className="px-4 py-3 text-right text-gray-900">
                    {formatCurrency(result.totalAccessoryCost)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </section>

        {/* Panel Maliyeti */}
        <section>
          <h3 className="text-lg font-semibold text-gray-700 mb-3">Panel Maliyeti</h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Panel Boyutları:</span>
                <span className="ml-2 font-medium text-gray-900">
                  {formatNumber(result.panelWidth)} x {formatNumber(result.panelDepth)} mm
                </span>
              </div>
              <div>
                <span className="text-gray-600">Panel Adedi:</span>
                <span className="ml-2 font-medium text-gray-900">{result.panelCount}</span>
              </div>
              <div>
                <span className="text-gray-600">Toplam Alan:</span>
                <span className="ml-2 font-medium text-gray-900">
                  {formatNumber(result.panelArea)} m²
                </span>
              </div>
              <div>
                <span className="text-gray-600">Panel Tutar:</span>
                <span className="ml-2 font-medium text-gray-900">
                  {formatCurrency(result.panelCost)}
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Toplam Maliyet */}
        <section className="border-t-2 pt-4">
          <div className="space-y-2">
            <div className="flex justify-between items-center text-gray-700">
              <span>Ara Toplam (KDV Hariç):</span>
              <span className="font-semibold text-lg">{formatCurrency(result.subtotal)}</span>
            </div>
            <div className="flex justify-between items-center text-gray-700">
              <span>KDV (%20):</span>
              <span className="font-semibold text-lg">{formatCurrency(result.vat)}</span>
            </div>
            <div className="flex justify-between items-center text-xl font-bold text-gray-900 bg-gray-100 rounded-lg p-3">
              <span>Net Maliyet:</span>
              <span>{formatCurrency(result.grandTotal)}</span>
            </div>
          </div>
        </section>
      </div>
      </div>
    </div>
  );
};
