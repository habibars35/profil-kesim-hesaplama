import { VerandaConfig, CalculationResult } from '../types';

interface DrawingViewProps {
  config: VerandaConfig;
  result: CalculationResult;
}

export default function DrawingView({ config, result }: DrawingViewProps) {
  const scale = 0.08;
  const offsetX = 60;
  const offsetY = 230;

  const backLineX = offsetX;
  const backLineY1 = offsetY - config.backHeight * scale;
  const backLineY2 = offsetY;

  const frontLineX = offsetX + config.depth * scale;
  const frontLineY1 = offsetY - result.frontHeight * scale;
  const frontLineY2 = offsetY;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
        <span className="text-2xl">📐</span>
        Teknik Kesit
      </h2>

      <div className="bg-gray-50 rounded-lg p-4">
        <svg
          viewBox="0 0 500 300"
          className="w-full h-auto"
          xmlns="http://www.w3.org/2000/svg"
        >
          <line
            x1={offsetX - 20}
            y1={offsetY}
            x2={frontLineX + 40}
            y2={offsetY}
            stroke="#64748b"
            strokeWidth="2"
          />

          <line
            x1={backLineX}
            y1={backLineY1}
            x2={backLineX}
            y2={backLineY2}
            stroke="#1e40af"
            strokeWidth="4"
          />

          <line
            x1={backLineX}
            y1={backLineY1}
            x2={frontLineX}
            y2={frontLineY1}
            stroke="#dc2626"
            strokeWidth="5"
          />

          <line
            x1={frontLineX}
            y1={frontLineY1}
            x2={frontLineX}
            y2={frontLineY2}
            stroke="#1e40af"
            strokeWidth="4"
          />

          <text
            x={backLineX - 15}
            y={(backLineY1 + backLineY2) / 2}
            fill="#dc2626"
            fontWeight="bold"
            fontSize="12"
            textAnchor="middle"
            transform={`rotate(-90, ${backLineX - 15}, ${(backLineY1 + backLineY2) / 2})`}
          >
            H1: {config.backHeight}mm
          </text>

          <text
            x={frontLineX + 15}
            y={(frontLineY1 + frontLineY2) / 2}
            fill="#2563eb"
            fontWeight="bold"
            fontSize="12"
            textAnchor="middle"
            transform={`rotate(90, ${frontLineX + 15}, ${(frontLineY1 + frontLineY2) / 2})`}
          >
            H2: {Math.round(result.frontHeight)}mm
          </text>

          <text
            x={(backLineX + frontLineX) / 2}
            y={offsetY + 20}
            fill="#059669"
            fontWeight="bold"
            fontSize="13"
            textAnchor="middle"
          >
            D: {config.depth}mm
          </text>

          <text
            x={(backLineX + frontLineX) / 2}
            y={backLineY1 - 10}
            fill="#1e293b"
            fontWeight="bold"
            fontSize="12"
            textAnchor="middle"
          >
            W: {config.width}mm
          </text>
        </svg>
      </div>
    </div>
  );
}
