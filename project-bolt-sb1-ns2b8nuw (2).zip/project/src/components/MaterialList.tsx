import { CalculationResult } from '../types';
import { formatCurrency, formatNumber } from '../utils/calculations';
import { Printer } from 'lucide-react';

interface MaterialListProps {
  result: CalculationResult;
}

export default function MaterialList({ result }: MaterialListProps) {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6 print:shadow-none">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
          <span className="text-2xl">📋</span>
          Malzeme Listesi
        </h2>
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-3 py-1.5 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors print:hidden text-sm"
        >
          <Printer className="w-4 h-4" />
          Yazdır
        </button>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-700 mb-3 border-l-4 border-blue-500 pl-3">
          Profil Listesi
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left font-semibold text-gray-600">Kod</th>
                <th className="px-4 py-3 text-left font-semibold text-gray-600">Açıklama</th>
                <th className="px-4 py-3 text-left font-semibold text-gray-600">Stok Uzunluk x Gerekli Boy x kg/m</th>
                <th className="px-4 py-3 text-right font-semibold text-gray-600">Toplam kg</th>
                <th className="px-4 py-3 text-right font-semibold text-gray-600">Tutar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {result.materials.map((material, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {material.imageUrl && (
                        <img
                          src={material.imageUrl}
                          alt={material.code}
                          className="w-10 h-10 object-cover rounded border"
                        />
                      )}
                      <span className="font-medium text-gray-900">{material.code}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-700">{material.name}</td>
                  <td className="px-4 py-3">
                    <div className="text-gray-700 font-mono text-xs leading-relaxed">
                      <div className="flex items-center gap-1">
                        <span className="inline-block bg-green-100 text-green-800 px-2 py-0.5 rounded text-xs font-semibold">
                          {material.stockBars} Boy
                        </span>
                        <span className="text-gray-900 font-semibold">
                          {material.stockLength}mm
                        </span>
                      </div>
                      <div className="mt-1 text-gray-600">
                        Kesim: <span className="text-gray-900 font-semibold">{Math.round(material.length)}mm</span> x <span className="text-gray-900 font-semibold">{material.quantity}</span> adet
                      </div>
                      <div className="mt-1 text-blue-600 font-semibold">
                        {formatNumber(material.kgPerMeter, 3)} kg/m
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right font-medium text-gray-900">
                    {formatNumber(material.stockTotalMeters * material.kgPerMeter, 2)} kg
                  </td>
                  <td className="px-4 py-3 text-right font-semibold text-blue-600">
                    {formatCurrency(material.stockTotalPrice)}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50">
              <tr>
                <td colSpan={3} className="px-4 py-3 text-right font-bold text-gray-700">
                  Toplam Profil:
                </td>
                <td className="px-4 py-3 text-right font-bold text-gray-900">
                  {formatNumber(result.materials.reduce((sum, m) => sum + (m.stockTotalMeters * m.kgPerMeter), 0), 2)} kg
                </td>
                <td className="px-4 py-3 text-right font-bold text-blue-600">
                  {formatCurrency(result.materials.reduce((sum, m) => sum + m.stockTotalPrice, 0))}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-700 mb-3 border-l-4 border-green-500 pl-3">
          Aksesuar ve Sarf Malzeme
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left font-semibold text-gray-600">Kod</th>
                <th className="px-4 py-3 text-left font-semibold text-gray-600">Aksesuar Adı</th>
                <th className="px-4 py-3 text-right font-semibold text-gray-600">Miktar</th>
                <th className="px-4 py-3 text-right font-semibold text-gray-600">Birim Fiyat</th>
                <th className="px-4 py-3 text-right font-semibold text-gray-600">Toplam Tutar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {result.accessories.map((accessory, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {accessory.imageUrl && (
                        <img
                          src={accessory.imageUrl}
                          alt={accessory.code}
                          className="w-10 h-10 object-cover rounded border"
                        />
                      )}
                      <span className="font-medium text-gray-900">{accessory.code}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-700">{accessory.name}</td>
                  <td className="px-4 py-3 text-right text-gray-700">{accessory.quantity}</td>
                  <td className="px-4 py-3 text-right text-gray-700">
                    {formatCurrency(accessory.unitPrice)}
                  </td>
                  <td className="px-4 py-3 text-right font-semibold text-green-600">
                    {formatCurrency(accessory.totalPrice)}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50">
              <tr>
                <td colSpan={4} className="px-4 py-3 text-right font-bold text-gray-700">
                  Toplam Aksesuar:
                </td>
                <td className="px-4 py-3 text-right font-bold text-green-600">
                  {formatCurrency(result.totalAccessoryCost)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}
