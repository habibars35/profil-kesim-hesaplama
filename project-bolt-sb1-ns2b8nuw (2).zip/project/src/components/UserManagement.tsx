import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { UserProfile } from '../types';
import { UserPlus, Edit2, Trash2, Save, X, Shield, User } from 'lucide-react';

export function UserManagement() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [showNewUser, setShowNewUser] = useState(false);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    full_name: '',
    company_name: '',
    is_admin: false,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading users:', error);
    } else if (data) {
      setUsers(data);
    }
  };

  const handleCreateUser = async () => {
    if (!newUser.username || !newUser.password || !newUser.full_name) {
      setError('Kullanıcı adı, şifre ve ad soyad gereklidir');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const email = `${newUser.username}@veranda.local`;

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password: newUser.password,
        options: {
          data: {
            full_name: newUser.full_name,
          },
        },
      });

      if (authError) throw authError;

      if (authData.user) {
        const { error: profileError } = await supabase
          .from('user_profiles')
          .insert({
            id: authData.user.id,
            username: newUser.username,
            full_name: newUser.full_name,
            company_name: newUser.company_name || null,
            is_admin: newUser.is_admin,
          });

        if (profileError) throw profileError;

        setNewUser({
          username: '',
          password: '',
          full_name: '',
          company_name: '',
          is_admin: false,
        });
        setShowNewUser(false);
        loadUsers();
      }
    } catch (err: any) {
      setError(err.message || 'Kullanıcı oluşturulurken hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUser = async () => {
    if (!editingUser) return;

    setLoading(true);
    setError('');

    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({
          full_name: editingUser.full_name,
          company_name: editingUser.company_name,
          is_admin: editingUser.is_admin,
        })
        .eq('id', editingUser.id);

      if (error) throw error;

      setEditingUser(null);
      loadUsers();
    } catch (err: any) {
      setError(err.message || 'Kullanıcı güncellenirken hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Bu kullanıcıyı silmek istediğinize emin misiniz?')) return;

    setLoading(true);
    setError('');

    try {
      const { error } = await supabase
        .from('user_profiles')
        .delete()
        .eq('id', userId);

      if (error) throw error;
      loadUsers();
    } catch (err: any) {
      setError(err.message || 'Kullanıcı silinirken hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Kullanıcı Yönetimi</h2>
        <button
          onClick={() => setShowNewUser(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center gap-2"
        >
          <UserPlus className="w-5 h-5" />
          Yeni Kullanıcı Ekle
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {showNewUser && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Yeni Kullanıcı Oluştur</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Kullanıcı Adı *
              </label>
              <input
                type="text"
                placeholder="kullaniciadi"
                value={newUser.username}
                onChange={(e) => setNewUser({ ...newUser, username: e.target.value.toLowerCase().replace(/\s/g, '') })}
                className="w-full px-4 py-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Şifre *
              </label>
              <input
                type="text"
                placeholder="Şifre (min 6 karakter)"
                value={newUser.password}
                onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg"
                minLength={6}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ad Soyad *
              </label>
              <input
                type="text"
                placeholder="Ad Soyad"
                value={newUser.full_name}
                onChange={(e) => setNewUser({ ...newUser, full_name: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Firma Adı
              </label>
              <input
                type="text"
                placeholder="Firma Adı (opsiyonel)"
                value={newUser.company_name}
                onChange={(e) => setNewUser({ ...newUser, company_name: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg"
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="is_admin"
                checked={newUser.is_admin}
                onChange={(e) => setNewUser({ ...newUser, is_admin: e.target.checked })}
                className="w-4 h-4"
              />
              <label htmlFor="is_admin" className="text-sm font-medium text-gray-700">
                Admin Yetkisi Ver
              </label>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleCreateUser}
              disabled={loading}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition flex items-center gap-2 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {loading ? 'Oluşturuluyor...' : 'Kullanıcı Oluştur'}
            </button>
            <button
              onClick={() => {
                setShowNewUser(false);
                setError('');
              }}
              className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition flex items-center gap-2"
            >
              <X className="w-4 h-4" />
              İptal
            </button>
          </div>
          <div className="mt-4 text-sm text-gray-600">
            <p><strong>Not:</strong> Kullanıcıya vereceğiniz giriş bilgileri:</p>
            <p className="mt-1">• Kullanıcı Adı: <strong>{newUser.username || '(henüz girilmedi)'}</strong></p>
            <p>• Şifre: <strong>{newUser.password || '(henüz girilmedi)'}</strong></p>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kullanıcı Adı</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ad Soyad</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Firma</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Yetki</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlemler</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {users.map((user) => (
              <tr key={user.id}>
                {editingUser?.id === user.id ? (
                  <>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-gray-500">{user.username}</span>
                    </td>
                    <td className="px-6 py-4">
                      <input
                        type="text"
                        value={editingUser.full_name}
                        onChange={(e) => setEditingUser({ ...editingUser, full_name: e.target.value })}
                        className="px-2 py-1 border rounded w-full"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <input
                        type="text"
                        value={editingUser.company_name || ''}
                        onChange={(e) => setEditingUser({ ...editingUser, company_name: e.target.value })}
                        className="px-2 py-1 border rounded w-full"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <select
                        value={editingUser.is_admin ? 'true' : 'false'}
                        onChange={(e) => setEditingUser({ ...editingUser, is_admin: e.target.value === 'true' })}
                        className="px-2 py-1 border rounded"
                      >
                        <option value="false">Kullanıcı</option>
                        <option value="true">Admin</option>
                      </select>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button
                          onClick={handleUpdateUser}
                          disabled={loading}
                          className="text-green-600 hover:text-green-700"
                        >
                          <Save className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => setEditingUser(null)}
                          className="text-gray-600 hover:text-gray-700"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </>
                ) : (
                  <>
                    <td className="px-6 py-4 whitespace-nowrap font-medium">{user.username}</td>
                    <td className="px-6 py-4">{user.full_name}</td>
                    <td className="px-6 py-4">{user.company_name || '-'}</td>
                    <td className="px-6 py-4">
                      {user.is_admin ? (
                        <span className="flex items-center gap-1 text-green-700">
                          <Shield className="w-4 h-4" />
                          Admin
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-gray-600">
                          <User className="w-4 h-4" />
                          Kullanıcı
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingUser(user)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Edit2 className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => handleDeleteUser(user.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
