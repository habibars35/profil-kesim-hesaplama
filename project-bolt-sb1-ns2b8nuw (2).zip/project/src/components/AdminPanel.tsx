import { useState, useEffect } from 'react';
import { X, Plus, Edit2, Trash2, Save, Upload } from 'lucide-react';
import { supabase, Profile, Accessory } from '../lib/supabase';
import { VariablesManagement } from './VariablesManagement';

interface AdminPanelProps {
  onClose: () => void;
}

export default function AdminPanel({ onClose }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'profiles' | 'accessories' | 'variables'>('profiles');
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [accessories, setAccessories] = useState<Accessory[]>([]);
  const [editingProfile, setEditingProfile] = useState<Partial<Profile> | null>(null);
  const [editingAccessory, setEditingAccessory] = useState<Partial<Accessory> | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const { data: profilesData } = await supabase
      .from('profiles')
      .select('*')
      .order('code');
    const { data: accessoriesData } = await supabase
      .from('accessories')
      .select('*')
      .order('code');

    if (profilesData) setProfiles(profilesData);
    if (accessoriesData) setAccessories(accessoriesData);
  };

  const uploadImage = async (file: File, type: 'profile' | 'accessory', code: string) => {
    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${type}-${code}-${Date.now()}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(filePath, file, { upsert: true });

      if (uploadError) {
        alert('Resim yüklenirken hata oluştu: ' + uploadError.message);
        return null;
      }

      const { data } = supabase.storage
        .from('product-images')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      alert('Resim yüklenirken hata oluştu');
      return null;
    } finally {
      setUploading(false);
    }
  };

  const handleProfileImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingProfile) return;

    const imageUrl = await uploadImage(file, 'profile', editingProfile.code || 'temp');
    if (imageUrl) {
      setEditingProfile({ ...editingProfile, image_url: imageUrl });
    }
  };

  const handleAccessoryImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingAccessory) return;

    const imageUrl = await uploadImage(file, 'accessory', editingAccessory.code || 'temp');
    if (imageUrl) {
      setEditingAccessory({ ...editingAccessory, image_url: imageUrl });
    }
  };

  const saveProfile = async () => {
    if (!editingProfile) return;
    setLoading(true);

    if (editingProfile.id) {
      await supabase
        .from('profiles')
        .update(editingProfile)
        .eq('id', editingProfile.id);
    } else {
      await supabase.from('profiles').insert([editingProfile]);
    }

    setEditingProfile(null);
    await loadData();
    setLoading(false);
  };

  const saveAccessory = async () => {
    if (!editingAccessory) return;
    setLoading(true);

    if (editingAccessory.id) {
      await supabase
        .from('accessories')
        .update(editingAccessory)
        .eq('id', editingAccessory.id);
    } else {
      await supabase.from('accessories').insert([editingAccessory]);
    }

    setEditingAccessory(null);
    await loadData();
    setLoading(false);
  };

  const deleteProfile = async (id: string) => {
    if (!confirm('Bu profili silmek istediğinize emin misiniz?')) return;
    await supabase.from('profiles').delete().eq('id', id);
    await loadData();
  };

  const deleteAccessory = async (id: string) => {
    if (!confirm('Bu aksesuarı silmek istediğinize emin misiniz?')) return;
    await supabase.from('accessories').delete().eq('id', id);
    await loadData();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <h2 className="text-2xl font-bold">Yönetim Paneli</h2>
          <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-lg transition">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex border-b">
          <button
            onClick={() => setActiveTab('profiles')}
            className={`flex-1 py-4 px-6 font-semibold transition ${
              activeTab === 'profiles'
                ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-700'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Profil Yönetimi
          </button>
          <button
            onClick={() => setActiveTab('accessories')}
            className={`flex-1 py-4 px-6 font-semibold transition ${
              activeTab === 'accessories'
                ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-700'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Aksesuar Yönetimi
          </button>
          <button
            onClick={() => setActiveTab('variables')}
            className={`flex-1 py-4 px-6 font-semibold transition ${
              activeTab === 'variables'
                ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-700'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Hesaplama Değişkenleri
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'profiles' && (
            <div>
              <div className="mb-6">
                <button
                  onClick={() =>
                    setEditingProfile({
                      code: '',
                      name: '',
                      stock1: 5000,
                      stock2: 6000,
                      kg_per_meter: 0,
                      profile_type: 2,
                    })
                  }
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
                >
                  <Plus className="w-5 h-5" />
                  Yeni Profil Ekle
                </button>
              </div>

              {editingProfile && (
                <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-bold mb-4 text-blue-900">
                    {editingProfile.id ? 'Profil Düzenle' : 'Yeni Profil'}
                  </h3>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Profil Kodu
                      </label>
                      <input
                        type="text"
                        value={editingProfile.code || ''}
                        onChange={(e) =>
                          setEditingProfile({ ...editingProfile, code: e.target.value })
                        }
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                        placeholder="L701"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Profil Adı
                      </label>
                      <input
                        type="text"
                        value={editingProfile.name || ''}
                        onChange={(e) =>
                          setEditingProfile({ ...editingProfile, name: e.target.value })
                        }
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                        placeholder="Oluk Profili"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Stok Boy 1 (mm)
                      </label>
                      <input
                        type="number"
                        value={editingProfile.stock1 || 5000}
                        onChange={(e) =>
                          setEditingProfile({
                            ...editingProfile,
                            stock1: parseInt(e.target.value),
                          })
                        }
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Stok Boy 2 (mm)
                      </label>
                      <input
                        type="number"
                        value={editingProfile.stock2 || 6000}
                        onChange={(e) =>
                          setEditingProfile({
                            ...editingProfile,
                            stock2: parseInt(e.target.value),
                          })
                        }
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Birim Ağırlık (kg/m)
                      </label>
                      <input
                        type="number"
                        step="0.001"
                        value={editingProfile.kg_per_meter || 0}
                        onChange={(e) =>
                          setEditingProfile({
                            ...editingProfile,
                            kg_per_meter: parseFloat(e.target.value),
                          })
                        }
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Profil Resmi
                      </label>
                      <div className="flex items-center gap-4">
                        {editingProfile.image_url && (
                          <img
                            src={editingProfile.image_url}
                            alt="Profil"
                            className="w-20 h-20 object-cover rounded-lg border-2 border-gray-300"
                          />
                        )}
                        <div className="flex-1">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleProfileImageUpload}
                            className="hidden"
                            id="profile-image-upload"
                            disabled={uploading}
                          />
                          <label
                            htmlFor="profile-image-upload"
                            className={`flex items-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-blue-500 transition ${
                              uploading ? 'opacity-50 cursor-not-allowed' : ''
                            }`}
                          >
                            <Upload className="w-5 h-5 text-gray-500" />
                            <span className="text-sm text-gray-600">
                              {uploading ? 'Yükleniyor...' : 'Resim Yükle veya Sürükle'}
                            </span>
                          </label>
                          {editingProfile.image_url && (
                            <button
                              type="button"
                              onClick={() => setEditingProfile({ ...editingProfile, image_url: null })}
                              className="mt-2 text-xs text-red-600 hover:underline"
                            >
                              Resmi Kaldır
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={saveProfile}
                      disabled={loading}
                      className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      Kaydet
                    </button>
                    <button
                      onClick={() => setEditingProfile(null)}
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition"
                    >
                      İptal
                    </button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-3 text-left font-semibold">Kod</th>
                      <th className="px-4 py-3 text-left font-semibold">Açıklama</th>
                      <th className="px-4 py-3 text-center font-semibold">Stok 1</th>
                      <th className="px-4 py-3 text-center font-semibold">Stok 2</th>
                      <th className="px-4 py-3 text-right font-semibold">kg/m</th>
                      <th className="px-4 py-3 text-center font-semibold">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {profiles.map((profile) => (
                      <tr key={profile.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            {profile.image_url && (
                              <img
                                src={profile.image_url}
                                alt={profile.code}
                                className="w-8 h-8 object-cover rounded border"
                              />
                            )}
                            <span className="font-bold">{profile.code}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">{profile.name}</td>
                        <td className="px-4 py-3 text-center">{profile.stock1}mm</td>
                        <td className="px-4 py-3 text-center">{profile.stock2}mm</td>
                        <td className="px-4 py-3 text-right">{profile.kg_per_meter}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => setEditingProfile(profile)}
                              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteProfile(profile.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'accessories' && (
            <div>
              <div className="mb-6">
                <button
                  onClick={() =>
                    setEditingAccessory({
                      code: '',
                      name: '',
                      unit_price: 0,
                    })
                  }
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
                >
                  <Plus className="w-5 h-5" />
                  Yeni Aksesuar Ekle
                </button>
              </div>

              {editingAccessory && (
                <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-bold mb-4 text-blue-900">
                    {editingAccessory.id ? 'Aksesuar Düzenle' : 'Yeni Aksesuar'}
                  </h3>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Aksesuar Kodu
                      </label>
                      <input
                        type="text"
                        value={editingAccessory.code || ''}
                        onChange={(e) =>
                          setEditingAccessory({ ...editingAccessory, code: e.target.value })
                        }
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                        placeholder="K-DUV"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Aksesuar Adı
                      </label>
                      <input
                        type="text"
                        value={editingAccessory.name || ''}
                        onChange={(e) =>
                          setEditingAccessory({ ...editingAccessory, name: e.target.value })
                        }
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                        placeholder="Duvar Lazer Kapak"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Birim Fiyat (₺)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={editingAccessory.unit_price || 0}
                        onChange={(e) =>
                          setEditingAccessory({
                            ...editingAccessory,
                            unit_price: parseFloat(e.target.value),
                          })
                        }
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Aksesuar Resmi
                      </label>
                      <div className="flex items-center gap-4">
                        {editingAccessory.image_url && (
                          <img
                            src={editingAccessory.image_url}
                            alt="Aksesuar"
                            className="w-20 h-20 object-cover rounded-lg border-2 border-gray-300"
                          />
                        )}
                        <div className="flex-1">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleAccessoryImageUpload}
                            className="hidden"
                            id="accessory-image-upload"
                            disabled={uploading}
                          />
                          <label
                            htmlFor="accessory-image-upload"
                            className={`flex items-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-blue-500 transition ${
                              uploading ? 'opacity-50 cursor-not-allowed' : ''
                            }`}
                          >
                            <Upload className="w-5 h-5 text-gray-500" />
                            <span className="text-sm text-gray-600">
                              {uploading ? 'Yükleniyor...' : 'Resim Yükle veya Sürükle'}
                            </span>
                          </label>
                          {editingAccessory.image_url && (
                            <button
                              type="button"
                              onClick={() => setEditingAccessory({ ...editingAccessory, image_url: null })}
                              className="mt-2 text-xs text-red-600 hover:underline"
                            >
                              Resmi Kaldır
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={saveAccessory}
                      disabled={loading}
                      className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      Kaydet
                    </button>
                    <button
                      onClick={() => setEditingAccessory(null)}
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition"
                    >
                      İptal
                    </button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-3 text-left font-semibold">Kod</th>
                      <th className="px-4 py-3 text-left font-semibold">Açıklama</th>
                      <th className="px-4 py-3 text-right font-semibold">Birim Fiyat</th>
                      <th className="px-4 py-3 text-center font-semibold">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {accessories.map((accessory) => (
                      <tr key={accessory.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            {accessory.image_url && (
                              <img
                                src={accessory.image_url}
                                alt={accessory.code}
                                className="w-8 h-8 object-cover rounded border"
                              />
                            )}
                            <span className="font-bold">{accessory.code}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">{accessory.name}</td>
                        <td className="px-4 py-3 text-right font-semibold">
                          {accessory.unit_price} ₺
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => setEditingAccessory(accessory)}
                              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteAccessory(accessory.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'variables' && <VariablesManagement />}
        </div>
      </div>
    </div>
  );
}
