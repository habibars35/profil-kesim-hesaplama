import { useEffect, useState } from 'react';
import { VerandaConfig, ProfileType, PanelType } from '../types';
import { supabase } from '../lib/supabase';

interface InputFormProps {
  config: VerandaConfig;
  onChange: (config: VerandaConfig) => void;
}

export default function InputForm({ config, onChange }: InputFormProps) {
  const [profileTypes, setProfileTypes] = useState<ProfileType[]>([]);
  const [panelTypes, setPanelTypes] = useState<PanelType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOptions();
  }, []);

  const loadOptions = async () => {
    try {
      const [profilesRes, panelsRes] = await Promise.all([
        supabase.from('profile_types').select('*').eq('is_active', true).order('name'),
        supabase.from('panel_types').select('*').eq('is_active', true).order('name'),
      ]);

      if (profilesRes.data) setProfileTypes(profilesRes.data);
      if (panelsRes.data) setPanelTypes(panelsRes.data);

      if (profilesRes.data && profilesRes.data.length > 0 && !config.profileTypeId) {
        onChange({ ...config, profileTypeId: profilesRes.data[0].id });
      }
      if (panelsRes.data && panelsRes.data.length > 0 && !config.panelTypeId) {
        onChange({ ...config, panelTypeId: panelsRes.data[0].id });
      }
    } catch (error) {
      console.error('Error loading options:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: keyof VerandaConfig, value: string | number) => {
    onChange({
      ...config,
      [field]: value,
    });
  };

  const selectedProfile = profileTypes.find(p => p.id === config.profileTypeId);
  const selectedPanel = panelTypes.find(p => p.id === config.panelTypeId);

  return (
    <div className="bg-white rounded-lg shadow-md p-4 sm:p-6 mb-4 sm:mb-6 print:hidden">
      <h2 className="text-lg sm:text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
        <span className="text-xl sm:text-2xl">⚙️</span>
        Veranda Konfigürasyonu
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div>
          <label className="block text-sm font-semibold text-gray-600 mb-1">
            Genişlik (mm)
          </label>
          <input
            type="number"
            value={config.width}
            onChange={(e) => handleChange('width', Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-600 mb-1">
            Derinlik (mm)
          </label>
          <input
            type="number"
            value={config.depth}
            onChange={(e) => handleChange('depth', Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-600 mb-1">
            Arka Yükseklik (mm)
          </label>
          <input
            type="number"
            value={config.backHeight}
            onChange={(e) => handleChange('backHeight', Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-600 mb-1">
            Eğim (%)
          </label>
          <input
            type="number"
            value={config.slope}
            onChange={(e) => handleChange('slope', Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-600 mb-1">
            Bölme Adedi
          </label>
          <input
            type="number"
            value={config.divisions}
            onChange={(e) => handleChange('divisions', Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-600 mb-1">
            Ayak Adedi
          </label>
          <input
            type="number"
            value={config.legs}
            onChange={(e) => handleChange('legs', Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-semibold text-gray-600 mb-1">
            Profil Türü
          </label>
          <select
            value={config.profileTypeId}
            onChange={(e) => handleChange('profileTypeId', e.target.value)}
            disabled={loading || profileTypes.length === 0}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
          >
            {profileTypes.length === 0 ? (
              <option>Profil türü bulunamadı</option>
            ) : (
              profileTypes.map((profile) => (
                <option key={profile.id} value={profile.id}>
                  {profile.name} - {profile.price_per_kg.toFixed(2)} TL/kg
                </option>
              ))
            )}
          </select>
          {selectedProfile && selectedProfile.description && (
            <p className="text-xs text-gray-500 mt-1">{selectedProfile.description}</p>
          )}
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-semibold text-gray-600 mb-1">
            Panel Türü
          </label>
          <select
            value={config.panelTypeId}
            onChange={(e) => handleChange('panelTypeId', e.target.value)}
            disabled={loading || panelTypes.length === 0}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
          >
            {panelTypes.length === 0 ? (
              <option>Panel türü bulunamadı</option>
            ) : (
              panelTypes.map((panel) => (
                <option key={panel.id} value={panel.id}>
                  {panel.name} - {panel.price_per_m2.toFixed(2)} TL/m²
                </option>
              ))
            )}
          </select>
          {selectedPanel && selectedPanel.description && (
            <p className="text-xs text-gray-500 mt-1">{selectedPanel.description}</p>
          )}
        </div>
      </div>
    </div>
  );
}
