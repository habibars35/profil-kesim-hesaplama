import { CalculationResult, VerandaConfig } from '../types';
import { formatCurrency, formatNumber } from '../utils/calculations';

interface PrintableSummaryProps {
  result: CalculationResult;
  config: VerandaConfig;
  profileTypeName?: string;
  profilePricePerKg?: number;
}

export default function PrintableSummary({ result, config, profileTypeName, profilePricePerKg }: PrintableSummaryProps) {
  return (
    <div className="print-summary">
      {profileTypeName && (
        <div className="mb-2 pb-2 border-b">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Profil Rengi:</span> {profileTypeName}
            {profilePricePerKg && (
              <span className="ml-4">
                <span className="font-semibold">Kg Fiyatı:</span> {formatCurrency(profilePricePerKg)}
              </span>
            )}
          </p>
        </div>
      )}
      {/* Ana Grid - 2 Sütun */}
      <div className="grid grid-cols-2 gap-4 mb-3">
        {/* Sol Kolon - Sistem Özellikleri */}
        <div>
          <h2 className="text-sm font-bold text-gray-800 mb-2 bg-gray-100 px-2 py-1">Sistem Özellikleri</h2>
          <div className="text-xs space-y-1">
            <div className="flex justify-between">
              <span className="text-gray-600">Cephe Genişlik:</span>
              <span className="font-semibold">{config.width} mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Derinlik:</span>
              <span className="font-semibold">{config.depth} mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Arka Yükseklik:</span>
              <span className="font-semibold">{config.backHeight} mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Ön Yükseklik:</span>
              <span className="font-semibold">{formatNumber(result.frontHeight)} mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Eğim:</span>
              <span className="font-semibold">%{config.slope}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Cam Bölme:</span>
              <span className="font-semibold">{config.divisions}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Ayak Sayısı:</span>
              <span className="font-semibold">{config.legs}</span>
            </div>
            <div className="flex justify-between border-t pt-1 mt-1">
              <span className="text-gray-700 font-medium">Panel:</span>
              <span className="font-semibold text-blue-600">
                {formatNumber(result.panelWidth)} x {formatNumber(result.panelDepth)} mm
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-700 font-medium">Panel m²:</span>
              <span className="font-semibold text-blue-600">{formatNumber(result.panelArea, 2)} m²</span>
            </div>
          </div>
        </div>

        {/* Sağ Kolon - Teknik Çizim */}
        <div>
          <h2 className="text-sm font-bold text-gray-800 mb-2 bg-gray-100 px-2 py-1">Teknik Kesit</h2>
          <svg
            viewBox="0 0 400 180"
            className="w-full h-auto border border-gray-300 rounded"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e5e7eb" strokeWidth="0.5"/>
              </pattern>
            </defs>
            <rect width="400" height="180" fill="url(#grid)" />

            {(() => {
              const scale = 0.05;
              const offsetX = 60;
              const offsetY = 140;

              const backLineX = offsetX;
              const backLineY1 = offsetY - config.backHeight * scale;
              const backLineY2 = offsetY;

              const frontLineX = offsetX + config.depth * scale;
              const frontLineY1 = offsetY - result.frontHeight * scale;
              const frontLineY2 = offsetY;

              return (
                <>
                  {/* Zemin çizgisi */}
                  <line
                    x1={offsetX - 20}
                    y1={offsetY}
                    x2={frontLineX + 40}
                    y2={offsetY}
                    stroke="#94a3b8"
                    strokeWidth="1"
                  />

                  {/* Arka dikey */}
                  <line
                    x1={backLineX}
                    y1={backLineY1}
                    x2={backLineX}
                    y2={backLineY2}
                    stroke="#1e40af"
                    strokeWidth="3"
                  />

                  {/* Üst yatay */}
                  <line
                    x1={backLineX}
                    y1={backLineY1}
                    x2={frontLineX}
                    y2={frontLineY1}
                    stroke="#16a34a"
                    strokeWidth="3"
                  />

                  {/* Ön dikey */}
                  <line
                    x1={frontLineX}
                    y1={frontLineY1}
                    x2={frontLineX}
                    y2={frontLineY2}
                    stroke="#1e40af"
                    strokeWidth="3"
                  />

                  {/* Ölçü etiketleri */}
                  <text
                    x={backLineX - 12}
                    y={(backLineY1 + backLineY2) / 2}
                    fill="#dc2626"
                    fontWeight="bold"
                    fontSize="9"
                    textAnchor="middle"
                    transform={`rotate(-90, ${backLineX - 12}, ${(backLineY1 + backLineY2) / 2})`}
                  >
                    H1: {config.backHeight}mm
                  </text>

                  <text
                    x={frontLineX + 12}
                    y={(frontLineY1 + frontLineY2) / 2}
                    fill="#2563eb"
                    fontWeight="bold"
                    fontSize="9"
                    textAnchor="middle"
                    transform={`rotate(90, ${frontLineX + 12}, ${(frontLineY1 + frontLineY2) / 2})`}
                  >
                    H2: {Math.round(result.frontHeight)}mm
                  </text>

                  <text
                    x={(backLineX + frontLineX) / 2}
                    y={offsetY + 15}
                    fill="#059669"
                    fontWeight="bold"
                    fontSize="10"
                    textAnchor="middle"
                  >
                    D: {config.depth}mm
                  </text>
                </>
              );
            })()}
          </svg>
        </div>
      </div>

      {/* Profil Listesi - Kompakt */}
      <div className="mb-2">
        <h2 className="text-sm font-bold text-gray-800 mb-1 bg-blue-50 px-2 py-1 border-l-4 border-blue-600">
          Profil Listesi
        </h2>
        <table className="w-full text-xs border-collapse">
          <thead className="bg-gray-100">
            <tr className="border-b border-gray-300">
              <th className="px-1 py-1 text-left font-semibold">Kod</th>
              <th className="px-1 py-1 text-left font-semibold">Açıklama</th>
              <th className="px-1 py-1 text-center font-semibold">kg/m</th>
              <th className="px-1 py-1 text-center font-semibold">Stok Boyu</th>
              <th className="px-1 py-1 text-center font-semibold">Boy</th>
              <th className="px-1 py-1 text-center font-semibold">Miktar</th>
              <th className="px-1 py-1 text-left font-semibold">Kesim Ölçüsü</th>
              <th className="px-1 py-1 text-right font-semibold">Fiyat</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {result.materials.map((material, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="px-1 py-1">
                  <div className="flex items-center gap-1">
                    {material.imageUrl && (
                      <img
                        src={material.imageUrl}
                        alt={material.code}
                        className="w-6 h-6 object-cover rounded border"
                      />
                    )}
                    <span className="font-medium">{material.code}</span>
                  </div>
                </td>
                <td className="px-1 py-1">{material.name}</td>
                <td className="px-1 py-1 text-center text-blue-600 font-semibold">
                  {formatNumber(material.kgPerMeter, 3)}
                </td>
                <td className="px-1 py-1 text-center text-purple-600 font-semibold">
                  {material.stockLength}mm
                </td>
                <td className="px-1 py-1 text-center">
                  <span className="bg-green-100 text-green-800 px-1 rounded text-xs font-semibold">
                    {material.stockBars}
                  </span>
                </td>
                <td className="px-1 py-1 text-center font-semibold">{material.quantity}</td>
                <td className="px-1 py-1 text-gray-700">
                  {Math.round(material.length)}mm
                </td>
                <td className="px-1 py-1 text-right font-semibold text-blue-600">
                  {formatCurrency(material.stockTotalPrice)}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-gray-100 font-bold">
            <tr className="border-t-2 border-gray-400">
              <td colSpan={7} className="px-1 py-1 text-right">Toplam Profil:</td>
              <td className="px-1 py-1 text-right text-blue-600">
                {formatCurrency(result.totalMaterialCost)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Aksesuar Listesi - Kompakt */}
      <div className="mb-2">
        <h2 className="text-sm font-bold text-gray-800 mb-1 bg-green-50 px-2 py-1 border-l-4 border-green-600">
          Aksesuar ve Sarf Malzeme
        </h2>
        <table className="w-full text-xs border-collapse">
          <thead className="bg-gray-100">
            <tr className="border-b border-gray-300">
              <th className="px-1 py-1 text-left font-semibold">Kod</th>
              <th className="px-1 py-1 text-left font-semibold">Aksesuar Adı</th>
              <th className="px-1 py-1 text-center font-semibold">Miktar</th>
              <th className="px-1 py-1 text-right font-semibold">Birim Fiyat</th>
              <th className="px-1 py-1 text-right font-semibold">Toplam</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {result.accessories.map((accessory, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="px-1 py-1">
                  <div className="flex items-center gap-1">
                    {accessory.imageUrl && (
                      <img
                        src={accessory.imageUrl}
                        alt={accessory.code}
                        className="w-6 h-6 object-cover rounded border"
                      />
                    )}
                    <span className="font-medium">{accessory.code}</span>
                  </div>
                </td>
                <td className="px-1 py-1">{accessory.name}</td>
                <td className="px-1 py-1 text-center font-semibold">{accessory.quantity}</td>
                <td className="px-1 py-1 text-right">{formatCurrency(accessory.unitPrice)}</td>
                <td className="px-1 py-1 text-right font-semibold text-green-600">
                  {formatCurrency(accessory.totalPrice)}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-gray-100 font-bold">
            <tr className="border-t-2 border-gray-400">
              <td colSpan={4} className="px-1 py-1 text-right">Toplam Aksesuar:</td>
              <td className="px-1 py-1 text-right text-green-600">
                {formatCurrency(result.totalAccessoryCost)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Toplam Fiyat */}
      <div className="mt-2 pt-2 border-t-2 border-gray-400">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-600">Profil Maliyeti:</span>
              <span className="font-semibold">{formatCurrency(result.totalMaterialCost)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Panel Maliyeti:</span>
              <span className="font-semibold">{formatCurrency(result.panelCost)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Aksesuar Maliyeti:</span>
              <span className="font-semibold">{formatCurrency(result.totalAccessoryCost)}</span>
            </div>
          </div>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between font-semibold">
              <span>Ara Toplam:</span>
              <span>{formatCurrency(result.subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span>KDV (%20):</span>
              <span>{formatCurrency(result.vat)}</span>
            </div>
            <div className="flex justify-between text-base font-bold bg-gray-800 text-white px-2 py-1 rounded">
              <span>Genel Toplam:</span>
              <span>{formatCurrency(result.grandTotal)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
