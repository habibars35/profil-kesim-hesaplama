import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Save } from 'lucide-react';

interface CalculationVariable {
  id: string;
  variable_name: string;
  value: number;
  description: string;
  unit: string;
  category?: string;
}

export function VariablesManagement() {
  const [variables, setVariables] = useState<CalculationVariable[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchVariables();
  }, []);

  const fetchVariables = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('calculation_variables')
        .select('*')
        .order('variable_name');

      if (error) throw error;
      setVariables(data || []);
    } catch (error) {
      console.error('Error fetching variables:', error);
      setMessage('Değişkenler yüklenirken hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const handleValueChange = (id: string, newValue: string) => {
    setVariables(prev =>
      prev.map(v => v.id === id ? { ...v, value: parseFloat(newValue) || 0 } : v)
    );
  };

  const handleSave = async (variable: CalculationVariable) => {
    try {
      setSaving(true);
      const { error } = await supabase
        .from('calculation_variables')
        .update({ value: variable.value, updated_at: new Date().toISOString() })
        .eq('id', variable.id);

      if (error) throw error;
      setMessage('Değişken başarıyla güncellendi');
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      console.error('Error updating variable:', error);
      setMessage('Güncelleme sırasında hata oluştu');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="text-center py-4">Yükleniyor...</div>;
  }

  // Group variables by category
  const categorizedVariables = variables.reduce((acc, variable) => {
    const category = variable.category || 'Genel';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(variable);
    return acc;
  }, {} as Record<string, CalculationVariable[]>);

  const categoryOrder = [
    'Ölçü Hesaplamaları',
    'Fiyat Hesaplamaları',
    'Aksesuar Hesaplamaları',
    'Stok Hesaplamaları',
    'Genel'
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-800 mb-2">Hesaplama Değişkenleri</h2>
        <p className="text-sm text-gray-600">
          Tüm hesaplama parametrelerini buradan yönetebilirsiniz. Yaptığınız değişiklikler anında tüm hesaplamalarda kullanılır.
        </p>
      </div>

      {message && (
        <div className={`p-4 rounded-lg ${message.includes('başarıyla') ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
          {message}
        </div>
      )}

      {categoryOrder.map((category) => {
        const categoryVariables = categorizedVariables[category];
        if (!categoryVariables || categoryVariables.length === 0) return null;

        return (
          <div key={category} className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700 border-b border-gray-300 pb-2">
              {category}
            </h3>
            <div className="grid gap-4 md:grid-cols-2">
              {categoryVariables.map((variable) => (
                <div key={variable.id} className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-gray-900">{variable.description}</h4>
                      <p className="text-xs text-gray-500 mt-1">
                        {variable.variable_name}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <input
                        type="number"
                        step={variable.unit === '%' ? '0.01' : '0.1'}
                        value={variable.value}
                        onChange={(e) => handleValueChange(variable.id, e.target.value)}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                      <span className="text-gray-600 font-medium min-w-[50px]">{variable.unit}</span>
                      <button
                        onClick={() => handleSave(variable)}
                        disabled={saving}
                        className="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        title="Kaydet"
                      >
                        <Save size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      <div className="bg-blue-50 p-5 rounded-lg border border-blue-200">
        <h3 className="font-semibold text-blue-900 mb-3">Temel Formüller</h3>
        <div className="space-y-2 text-sm text-blue-800">
          <p><strong>Panel Genişliği:</strong> (Toplam Genişlik - (Bölme Sayısı + 1) × Kayıt Genişliği) ÷ Bölme Sayısı + Profil Binme Payı</p>
          <p><strong>Panel Uzunluğu:</strong> Kayıt Profil Boyu (Hipotenüs - Kayıt Profil Payı) + Panel Uzunluk Payı</p>
          <p><strong>Bacak Yüksekliği:</strong> Arka Yükseklik - Eğim Farkı - Bacak Aşağı Payı</p>
          <p><strong>KDV:</strong> Ara Toplam × KDV Oranı</p>
        </div>
      </div>
    </div>
  );
}
