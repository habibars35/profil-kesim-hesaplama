import { Calculator, Printer } from 'lucide-react';
import { CalculationResult } from '../types';
import { formatCurrency } from '../utils/calculations';

interface PriceSummaryProps {
  result: CalculationResult;
}

export default function PriceSummary({ result }: PriceSummaryProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
        <Calculator className="w-6 h-6" />
        Fiyat Özeti
      </h2>

      <div className="space-y-3">
        <div className="py-2 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <span className="text-gray-600">
              Profil Maliyeti:
              <span className="text-sm text-gray-500 ml-1">
                ({result.materials.reduce((sum, m) => sum + (m.stockTotalMeters * m.kgPerMeter), 0).toFixed(2)} kg)
              </span>
            </span>
            <span className="font-semibold text-gray-900">
              {formatCurrency(result.totalMaterialCost)}
            </span>
          </div>
        </div>

        {result.panelCost !== undefined && result.panelCost > 0 && (
          <div className="py-2 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">
                Panel Maliyeti:
                {result.panelArea && (
                  <span className="text-sm text-gray-500 ml-1">
                    ({result.panelArea.toFixed(2)} m²)
                  </span>
                )}
              </span>
              <span className="font-semibold text-gray-900">
                {formatCurrency(result.panelCost)}
              </span>
            </div>
            {result.panelWidth && result.panelDepth && result.panelCount && (
              <div className="mt-1 text-xs text-gray-500">
                {result.panelCount} adet panel: {Math.round(result.panelWidth)} mm x {Math.round(result.panelDepth)} mm
              </div>
            )}
          </div>
        )}

        <div className="flex justify-between items-center py-2 border-b border-gray-200">
          <span className="text-gray-600">Aksesuar Maliyeti:</span>
          <span className="font-semibold text-gray-900">
            {formatCurrency(result.totalAccessoryCost)}
          </span>
        </div>

        <div className="flex justify-between items-center py-2 border-b-2 border-gray-400">
          <span className="text-gray-700 font-medium">Ara Toplam:</span>
          <span className="font-bold text-gray-900 text-lg">
            {formatCurrency(result.subtotal)}
          </span>
        </div>

        <div className="flex justify-between items-center py-2">
          <span className="text-gray-600">KDV (%20):</span>
          <span className="font-semibold text-gray-700">
            {formatCurrency(result.vat)}
          </span>
        </div>

        <div className="flex justify-between items-center py-3 bg-blue-50 px-4 rounded-lg mt-4">
          <span className="text-blue-900 font-bold text-lg">Genel Toplam:</span>
          <span className="font-bold text-blue-600 text-2xl">
            {formatCurrency(result.grandTotal)}
          </span>
        </div>
      </div>

      <button
        onClick={() => window.print()}
        className="mt-6 w-full bg-gray-800 hover:bg-gray-700 text-white font-semibold py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
      >
        <Printer className="w-5 h-5" />
        Yazdır / PDF
      </button>
    </div>
  );
}
