import { useState, useEffect } from 'react';
import { Settings, LogOut, Shield, Users, FileText, Scissors, Calculator, Receipt, Printer, Download } from 'lucide-react';
import { VerandaConfig, CalculationResult, ProfileType, PanelType } from './types';
import { calculateVeranda } from './utils/calculations';
import { generatePDF } from './utils/pdfExport';
import InputForm from './components/InputForm';
import DrawingView from './components/DrawingView';
import MaterialList from './components/MaterialList';
import PriceSummary from './components/PriceSummary';
import AdminPanel from './components/AdminPanel';
import { PricingAdmin } from './components/PricingAdmin';
import { UserManagement } from './components/UserManagement';
import { AuthForm } from './components/AuthForm';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { CostAnalysisReport } from './components/CostAnalysisReport';
import { QuotationForm } from './components/QuotationForm';
import { CuttingReport } from './components/CuttingReport';
import PrintableSummary from './components/PrintableSummary';
import { supabase } from './lib/supabase';

function AppContent() {
  const { user, userProfile, loading: authLoading, signOut } = useAuth();
  const [config, setConfig] = useState<VerandaConfig>({
    width: 5000,
    depth: 3000,
    backHeight: 2600,
    slope: 8,
    divisions: 7,
    legs: 2,
    profileTypeId: '',
    panelTypeId: '',
  });

  const [result, setResult] = useState<CalculationResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [showUserManagement, setShowUserManagement] = useState(false);
  const [viewMode, setViewMode] = useState<'summary' | 'cutting' | 'cost' | 'quotation'>('summary');
  const [profileTypes, setProfileTypes] = useState<ProfileType[]>([]);
  const [panelTypes, setPanelTypes] = useState<PanelType[]>([]);

  useEffect(() => {
    const loadTypes = async () => {
      try {
        const [profilesRes, panelsRes] = await Promise.all([
          supabase.from('profile_types').select('*').eq('is_active', true).order('name'),
          supabase.from('panel_types').select('*').eq('is_active', true).order('name'),
        ]);
        if (profilesRes.data) setProfileTypes(profilesRes.data);
        if (panelsRes.data) setPanelTypes(panelsRes.data);
      } catch (error) {
        console.error('Error loading types:', error);
      }
    };
    loadTypes();
  }, []);

  useEffect(() => {
    if (config.profileTypeId && config.panelTypeId) {
      const calculate = async () => {
        setLoading(true);
        const newResult = await calculateVeranda(config);
        setResult(newResult);
        setLoading(false);
      };
      calculate();
    }
  }, [config]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthForm />;
  }

  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const selectedProfileType = profileTypes.find(p => p.id === config.profileTypeId);
  const selectedPanelType = panelTypes.find(p => p.id === config.panelTypeId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-200">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-8">
        <header className="mb-6 sm:mb-8 print:mb-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800 mb-1 sm:mb-2 print:text-3xl">
                Veranda Kış Bahçesi Hesaplama
              </h1>
              <p className="text-sm sm:text-base text-gray-600 print:hidden truncate">
                Hoş geldiniz, {userProfile?.full_name || user.email}
                {userProfile?.company_name && ` - ${userProfile.company_name}`}
              </p>
            </div>

            <div className="flex items-center gap-2 print:hidden flex-shrink-0">
              {userProfile?.is_admin && (
                <>
                  <button
                    onClick={() => {
                      setShowUserManagement(!showUserManagement);
                      setShowPricing(false);
                      setShowAdmin(false);
                    }}
                    className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-2 bg-purple-600 text-white rounded-lg shadow hover:bg-purple-700 active:bg-purple-800 transition text-sm"
                    title="Kullanıcı Yönetimi"
                  >
                    <Users className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span className="hidden sm:inline">Kullanıcılar</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowPricing(!showPricing);
                      setShowAdmin(false);
                      setShowUserManagement(false);
                    }}
                    className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-2 bg-green-600 text-white rounded-lg shadow hover:bg-green-700 active:bg-green-800 transition text-sm"
                    title="Fiyat Yönetimi"
                  >
                    <Shield className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span className="hidden sm:inline">Fiyatlar</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowAdmin(!showAdmin);
                      setShowPricing(false);
                      setShowUserManagement(false);
                    }}
                    className="p-2 bg-white rounded-lg shadow hover:bg-gray-50 active:bg-gray-100 transition"
                    title="Profil & Aksesuar Yönetimi"
                  >
                    <Settings className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                  </button>
                </>
              )}
              <button
                onClick={handleLogout}
                className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-2 bg-white rounded-lg shadow hover:bg-gray-50 active:bg-gray-100 transition text-sm"
                title="Çıkış Yap"
              >
                <LogOut className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                <span className="hidden sm:inline">Çıkış</span>
              </button>
            </div>
          </div>
        </header>

        {showUserManagement && userProfile?.is_admin && (
          <div className="mb-6 print:hidden">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-gray-800">Kullanıcı Yönetimi</h2>
                <button
                  onClick={() => setShowUserManagement(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>
              <UserManagement />
            </div>
          </div>
        )}

        {showPricing && userProfile?.is_admin && (
          <div className="mb-6 print:hidden">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-gray-800">Fiyat Yönetimi</h2>
                <button
                  onClick={() => setShowPricing(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>
              <PricingAdmin />
            </div>
          </div>
        )}

        {showAdmin && userProfile?.is_admin && (
          <div className="print:hidden">
            <AdminPanel onClose={() => setShowAdmin(false)} />
          </div>
        )}

        {!showPricing && !showAdmin && !showUserManagement && (
          <>
            <InputForm config={config} onChange={setConfig} />

            {loading && (
              <div className="text-center py-12">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
                <p className="mt-4 text-gray-600">Hesaplanıyor...</p>
              </div>
            )}

            {!loading && result && config.profileTypeId && config.panelTypeId && (
              <>
                {/* Görünüm Seçici */}
                <div className="mb-6 print:hidden">
                  <div className="flex flex-wrap gap-2 bg-white rounded-lg shadow-md p-2">
                    <button
                      onClick={() => setViewMode('summary')}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
                        viewMode === 'summary'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <FileText className="w-4 h-4" />
                      Özet & Çizim
                    </button>
                    <button
                      onClick={() => setViewMode('cutting')}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
                        viewMode === 'cutting'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <Scissors className="w-4 h-4" />
                      Kesim Raporu
                    </button>
                    <button
                      onClick={() => setViewMode('cost')}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
                        viewMode === 'cost'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <Calculator className="w-4 h-4" />
                      Malzeme Listesi
                    </button>
                    <button
                      onClick={() => setViewMode('quotation')}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
                        viewMode === 'quotation'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <Receipt className="w-4 h-4" />
                      Fiyat Teklifi
                    </button>
                  </div>
                </div>

                {/* İçerik */}
                {viewMode === 'summary' && (
                  <>
                    <div className="mb-4 flex justify-end gap-2 print:hidden">
                      <button
                        onClick={async () => {
                          try {
                            await generatePDF('summary-content', `ozet-rapor-${new Date().toLocaleDateString('tr-TR')}.pdf`);
                          } catch (error) {
                            console.error('PDF oluşturma hatası:', error);
                            alert('PDF oluşturulurken bir hata oluştu.');
                          }
                        }}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <Download className="w-4 h-4" />
                        PDF İndir
                      </button>
                      <button
                        onClick={() => window.print()}
                        className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
                      >
                        <Printer className="w-4 h-4" />
                        Yazdır
                      </button>
                    </div>
                    <div id="summary-content" className="bg-white rounded-lg shadow-md p-4 print:shadow-none print:p-0">
                      <PrintableSummary
                        result={result}
                        config={config}
                        profileTypeName={selectedProfileType?.name}
                        profilePricePerKg={selectedProfileType?.price_per_kg}
                      />
                    </div>
                  </>
                )}

                {viewMode === 'cutting' && <CuttingReport result={result} profileTypeName={selectedProfileType?.name} />}

                {viewMode === 'cost' && <CostAnalysisReport result={result} />}

                {viewMode === 'quotation' && <QuotationForm result={result} config={config} profileTypeName={selectedProfileType?.name} panelTypeName={selectedPanelType?.name} />}
              </>
            )}
          </>
        )}

        <footer className="text-center mt-8 text-gray-500 text-sm print:hidden">
          <p>© 2024 Lockwin Veranda Sistemleri</p>
        </footer>
      </div>

      <style>{`
        @media print {
          @page {
            size: A4;
            margin: 0.8cm;
          }
          body {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
          .print-summary {
            font-size: 11px;
          }
          .print-summary h1 {
            font-size: 18px;
          }
          .print-summary h2 {
            font-size: 12px;
          }
          .print-summary table {
            font-size: 9px;
          }
        }
      `}</style>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
