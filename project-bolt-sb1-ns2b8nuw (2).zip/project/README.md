# Veranda & Kış Bahçesi Hesaplama Sistemi

Profesyonel veranda ve kış bahçesi fiyat hesaplama, teklif ve maliyet analizi sistemi.

## Özellikler

- Anlık fiyat hesaplama ve teklif oluşturma
- Malzeme listesi ve kesim raporu
- PDF export ve yazdırma
- Teknik çizim görselleştirme
- Kullanıcı yönetimi ve yetkilendirme
- Fiyat ve değişken yönetimi
- Mobil uyumlu responsive tasarım

## Teknolojiler

- React + TypeScript
- Vite
- Tailwind CSS
- Supabase (Veritabanı & Auth)
- jsPDF (PDF Export)

## Kurulum

```bash
# Bağımlılıkları yükle
npm install

# Geliştirme sunucusunu başlat
npm run dev

# Production build
npm run build

# Build önizleme
npm run preview
```

## Deployment (Yayınlama)

### 1. Netlify (Önerilen)

Netlify üzerinde projeyi yayınlamak en kolay yöntemdir:

1. [Netlify](https://www.netlify.com) hesabı oluşturun (GitHub ile giriş yapabilirsiniz)
2. "Add new site" > "Import an existing project"
3. GitHub reponuzu bağlayın
4. Build ayarları:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Environment variables bölümünden Supabase bilgilerini ekleyin:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
6. "Deploy" butonuna tıklayın

**Avantajları:**
- Ücretsiz SSL sertifikası
- Otomatik CI/CD
- Hızlı global CDN
- Ücretsiz plan yeterli

### 2. Vercel

1. [Vercel](https://vercel.com) hesabı oluşturun
2. "New Project" > GitHub reponuzu seçin
3. Framework: Vite
4. Build command: `npm run build`
5. Output directory: `dist`
6. Environment variables ekleyin
7. Deploy

### 3. GitHub Pages

```bash
# Build oluştur
npm run build

# dist klasörünü gh-pages branch'ine deploy et
npm install -g gh-pages
gh-pages -d dist
```

### 4. Kendi Sunucunuz

```bash
# Build oluştur
npm run build

# dist klasörünü sunucunuza yükleyin
# Nginx veya Apache ile servis edin
```

Örnek Nginx config:

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/veranda/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

## Environment Variables

`.env` dosyası oluşturun:

```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Veritabanı

Proje Supabase kullanmaktadır. Migration dosyaları `supabase/migrations` klasöründedir.

Supabase dashboard'dan SQL Editor'ü kullanarak migration dosyalarını sırayla çalıştırın.

## İlk Kullanım

1. Uygulamayı açın
2. "Kayıt Ol" ile admin kullanıcısı oluşturun
3. Supabase dashboard'dan `user_profiles` tablosunda kullanıcının `is_admin` değerini `true` yapın
4. Admin olarak giriş yapın
5. "Fiyatlar" menüsünden profil ve panel türlerini ekleyin
6. "Değişkenler" menüsünden hesaplama değişkenlerini ayarlayın

## Lisans

MIT
