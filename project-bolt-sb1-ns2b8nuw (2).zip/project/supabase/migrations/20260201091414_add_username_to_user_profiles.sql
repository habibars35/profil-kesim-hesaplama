/*
  # Kullanıcı Adı Sistemi Ekleme

  1. Değişiklikler
    - `user_profiles` tablosuna `username` alanı ekleme
    - Username unique olmalı
    - Admin kullanıcı oluşturma özelliği için function

  2. Notlar
    - Kullanıcılar artık username ve şifre ile giriş yapacak
    - Email otomatik olarak username@veranda.local formatında oluşturulacak
*/

-- username alanı ekle
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'username'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN username text UNIQUE;
  END IF;
END $$;

-- Mevcut kullanıcılar için username oluştur (email'den önce @ olan kısmı al)
UPDATE user_profiles
SET username = SPLIT_PART((SELECT email FROM auth.users WHERE auth.users.id = user_profiles.id), '@', 1)
WHERE username IS NULL;

-- Admin kullanıcı oluşturma fonksiyonu
CREATE OR REPLACE FUNCTION create_user_account(
  p_username text,
  p_password text,
  p_full_name text,
  p_company_name text DEFAULT NULL,
  p_is_admin boolean DEFAULT false
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id uuid;
  v_email text;
BEGIN
  -- Sadece admin kullanıcılar yeni hesap oluşturabilir
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Sadece admin kullanıcılar yeni hesap oluşturabilir';
  END IF;

  -- Username'den email oluştur
  v_email := p_username || '@veranda.local';

  -- Yeni kullanıcı oluştur (Supabase Auth)
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    confirmation_token,
    recovery_token
  ) VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    v_email,
    crypt(p_password, gen_salt('bf')),
    NOW(),
    '{"provider":"email","providers":["email"]}',
    jsonb_build_object('full_name', p_full_name),
    NOW(),
    NOW(),
    '',
    ''
  )
  RETURNING id INTO v_user_id;

  -- Kullanıcı profili oluştur
  INSERT INTO user_profiles (
    id,
    username,
    full_name,
    company_name,
    is_admin
  ) VALUES (
    v_user_id,
    p_username,
    p_full_name,
    p_company_name,
    p_is_admin
  );

  RETURN json_build_object(
    'success', true,
    'user_id', v_user_id,
    'username', p_username
  );
END;
$$;

-- İlk admin kullanıcısı oluştur (eğer hiç admin yoksa)
DO $$
DECLARE
  admin_count integer;
BEGIN
  SELECT COUNT(*) INTO admin_count FROM user_profiles WHERE is_admin = true;
  
  IF admin_count = 0 THEN
    PERFORM create_user_account(
      'admin',
      'admin123',
      'Sistem Yöneticisi',
      NULL,
      true
    );
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    -- Hata olursa sessizce devam et
    NULL;
END $$;