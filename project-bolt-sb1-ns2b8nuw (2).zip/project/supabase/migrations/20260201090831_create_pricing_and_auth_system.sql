/*
  # Fiyatlandırma ve Kullanıcı Girişi Sistemi

  1. Yeni Tablolar
    - `user_profiles`
      - `id` (uuid, primary key, references auth.users)
      - `full_name` (text)
      - `company_name` (text, optional)
      - `phone` (text, optional)
      - `is_admin` (boolean, default false)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `profile_types` (Profil Renkleri/Türleri)
      - `id` (uuid, primary key)
      - `name` (text, unique) - örn: "Press Profil", "Rall Boyalı", "Ahşap Kaplama"
      - `price_per_meter` (numeric) - metre başına fiyat
      - `description` (text, optional)
      - `is_active` (boolean, default true)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `panel_types` (Cam/Panel Türleri)
      - `id` (uuid, primary key)
      - `name` (text, unique) - örn: "8mm Şeffaf Cam", "4+12+4 Konfor Isıcam"
      - `price_per_m2` (numeric) - metrekare başına fiyat
      - `description` (text, optional)
      - `is_active` (boolean, default true)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Güvenlik
    - RLS tüm tablolarda aktif
    - user_profiles: Kullanıcılar kendi profillerini görebilir/güncelleyebilir
    - profile_types & panel_types: Herkes okuyabilir, sadece admin ekleyip düzenleyebilir
    - Admin kontrolü için helper function

  3. Başlangıç Verileri
    - Varsayılan profil türleri ve fiyatları
    - Varsayılan panel türleri ve fiyatları
*/

-- user_profiles tablosu
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  company_name text,
  phone text,
  is_admin boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- profile_types tablosu (Profil Renkleri)
CREATE TABLE IF NOT EXISTS profile_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  price_per_meter numeric NOT NULL DEFAULT 0,
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- panel_types tablosu (Cam/Panel Türleri)
CREATE TABLE IF NOT EXISTS panel_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  price_per_m2 numeric NOT NULL DEFAULT 0,
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- RLS Etkinleştirme
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE profile_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE panel_types ENABLE ROW LEVEL SECURITY;

-- Helper function: Admin kontrolü
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_profiles
    WHERE id = auth.uid() AND is_admin = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- user_profiles RLS Policies
CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- profile_types RLS Policies
CREATE POLICY "Anyone can view active profile types"
  ON profile_types FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Admins can view all profile types"
  ON profile_types FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can insert profile types"
  ON profile_types FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "Admins can update profile types"
  ON profile_types FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can delete profile types"
  ON profile_types FOR DELETE
  TO authenticated
  USING (is_admin());

-- panel_types RLS Policies
CREATE POLICY "Anyone can view active panel types"
  ON panel_types FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Admins can view all panel types"
  ON panel_types FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can insert panel types"
  ON panel_types FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "Admins can update panel types"
  ON panel_types FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can delete panel types"
  ON panel_types FOR DELETE
  TO authenticated
  USING (is_admin());

-- Başlangıç Verileri: Profil Türleri
INSERT INTO profile_types (name, price_per_meter, description) VALUES
  ('Press Profil', 150.00, 'Standart press profil'),
  ('Rall Boyalı', 200.00, 'Elektrostatik toz boya ile boyanmış profil'),
  ('Ahşap Kaplama', 280.00, 'Ahşap görünümlü kaplama profil')
ON CONFLICT (name) DO NOTHING;

-- Başlangıç Verileri: Panel Türleri
INSERT INTO panel_types (name, price_per_m2, description) VALUES
  ('8mm Şeffaf Cam', 450.00, 'Standart 8mm temperli şeffaf cam'),
  ('8mm Renkli Cam', 520.00, 'Renkli 8mm temperli cam'),
  ('4+12+4 Konfor Isıcam', 680.00, 'Çift cam ısıcam sistemi'),
  ('4+12+4 Renkli Isıcam', 750.00, 'Renkli çift cam ısıcam sistemi'),
  ('Kompozit Panel', 420.00, 'Alüminyum kompozit panel')
ON CONFLICT (name) DO NOTHING;

-- Trigger: updated_at otomatik güncelleme
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_profile_types_updated_at
  BEFORE UPDATE ON profile_types
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_panel_types_updated_at
  BEFORE UPDATE ON panel_types
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();