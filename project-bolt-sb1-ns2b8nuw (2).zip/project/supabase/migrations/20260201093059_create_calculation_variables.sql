/*
  # Create calculation variables table

  1. New Tables
    - `calculation_variables`
      - `id` (uuid, primary key)
      - `variable_name` (text, unique) - Variable identifier
      - `value` (numeric) - Variable value
      - `description` (text) - Description of the variable
      - `unit` (text) - Unit of measurement (mm, etc.)
      - `updated_at` (timestamptz) - Last update timestamp
  
  2. Security
    - Enable RLS on `calculation_variables` table
    - Add policy for authenticated users to read variables
    - Add policy for admin users to update variables
  
  3. Initial Data
    - Insert default calculation variables:
      - kayit_genisligi (61 mm) - Width of the sliding track
      - profil_binme_payi (35 mm) - Profile overlap allowance
      - uzunluk_payi (30 mm) - Length allowance
*/

CREATE TABLE IF NOT EXISTS calculation_variables (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  variable_name text UNIQUE NOT NULL,
  value numeric NOT NULL,
  description text NOT NULL,
  unit text DEFAULT 'mm',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE calculation_variables ENABLE ROW LEVEL SECURITY;

-- Everyone can read calculation variables
CREATE POLICY "Anyone can read calculation variables"
  ON calculation_variables FOR SELECT
  TO authenticated
  USING (true);

-- Only admins can update calculation variables
CREATE POLICY "Admins can update calculation variables"
  ON calculation_variables FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

-- Insert default calculation variables
INSERT INTO calculation_variables (variable_name, value, description, unit) VALUES
  ('kayit_genisligi', 61, 'Kayıt genişliği', 'mm'),
  ('profil_binme_payi', 35, 'Profil binme payı', 'mm'),
  ('uzunluk_payi', 30, 'Uzunluk payı', 'mm')
ON CONFLICT (variable_name) DO NOTHING;