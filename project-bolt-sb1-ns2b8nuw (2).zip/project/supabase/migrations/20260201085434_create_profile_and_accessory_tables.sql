/*
  # Veranda Profil ve Aksesuar Tabloları

  1. Yeni Tablolar
    - `profiles`
      - `id` (uuid, primary key)
      - `code` (text, unique) - Profil kodu (örn: L701, L702)
      - `name` (text) - Profil açıklaması
      - `image_url` (text, nullable) - Profil resim URL'si
      - `stock1` (integer) - 1. stok boyu (mm)
      - `stock2` (integer) - 2. stok boyu (mm)
      - `kg_per_meter` (numeric) - Birim ağırlık (kg/m)
      - `profile_type` (integer) - Tip (1 veya 2 - stok optimizasyonu için)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `accessories`
      - `id` (uuid, primary key)
      - `code` (text, unique) - Aksesuar kodu
      - `name` (text) - Aksesuar açıklaması
      - `image_url` (text, nullable) - Aksesuar resim URL'si
      - `unit_price` (numeric) - Birim fiyat (TL)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Güvenlik
    - Her iki tablo için RLS etkinleştirildi
    - Herkes okuma yapabilir (public erişim)
    - Sadece authenticated kullanıcılar yazabilir
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  image_url text,
  stock1 integer NOT NULL DEFAULT 5000,
  stock2 integer NOT NULL DEFAULT 6000,
  kg_per_meter numeric(10,3) NOT NULL,
  profile_type integer NOT NULL DEFAULT 2,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS accessories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  image_url text,
  unit_price numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE accessories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read profiles"
  ON profiles FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert profiles"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update profiles"
  ON profiles FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete profiles"
  ON profiles FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can read accessories"
  ON accessories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert accessories"
  ON accessories FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update accessories"
  ON accessories FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete accessories"
  ON accessories FOR DELETE
  TO authenticated
  USING (true);

-- Örnek veriler ekle
INSERT INTO profiles (code, name, stock1, stock2, kg_per_meter, profile_type) VALUES
  ('L701', 'Oluk Profili', 5000, 6000, 6.200, 2),
  ('L702', 'Arka Askı Profili', 5000, 6000, 2.600, 2),
  ('L703', 'Ayak Profili', 5000, 7000, 3.100, 1),
  ('L704', 'Ayak Kapak', 5000, 7000, 1.050, 1),
  ('L705', 'Kayıt Profili', 5000, 7000, 2.900, 2),
  ('L706', 'Yan Baskı Profil', 5000, 7000, 0.900, 2),
  ('L707', 'Orta Baskı Profil', 5000, 7000, 0.700, 2),
  ('L709', 'Duvar-Oluk Kapatma', 5000, 6000, 0.500, 2)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accessories (code, name, unit_price) VALUES
  ('K-DUV', 'Duvar Lazer Kapak', 175),
  ('K-OLU', 'Oluk Lazer Kapak', 220),
  ('F-FLN', 'Ayak Lazer Takım', 450),
  ('FIT-O', 'Duvar Profil Conta', 65),
  ('FIT-C', 'Panel Contası', 25)
ON CONFLICT (code) DO NOTHING;
