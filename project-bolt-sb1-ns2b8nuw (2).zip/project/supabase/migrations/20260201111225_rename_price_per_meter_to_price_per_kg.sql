/*
  # Profil Fiyatlandırmasını KG Bazına Çevir
  
  1. Değişiklikler
    - `profile_types` tablosunda `price_per_meter` alanını `price_per_kg` olarak yeniden adlandır
    - Bu değişiklik fiyatlandırmanın kg bazında yapılması için gerekli
    
  2. Neden Gerekli
    - Alüminyum profil fiyatları genelde kg bazında hesaplanır
    - Mevcut isim (price_per_meter) yanlış anlaşılmaya sebep oluyordu
    - Fiyat hesaplamalarında doğru sonuçlar için kg bazında hesaplama yapılmalı
*/

-- Rename column from price_per_meter to price_per_kg
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profile_types' AND column_name = 'price_per_meter'
  ) THEN
    ALTER TABLE profile_types RENAME COLUMN price_per_meter TO price_per_kg;
  END IF;
END $$;