/*
  # Add All Calculation Variables for Complete Database Control
  
  1. Purpose
    - Add all missing calculation variables to database
    - Remove hardcoded values from code
    - Enable full admin control over all calculations
  
  2. New Variables Added
    - kdv_orani (0.20) - VAT/Tax rate (20%)
    - bacak_asagi_payi (180 mm) - Leg height deduction
    - fit_meter_carpani (1000) - Multiplier for fit calculations per meter
    - default_stock1 (6000 mm) - Default stock length 1
    - default_stock2 (5500 mm) - Default stock length 2
  
  3. Categories
    - Ölçü Hesaplamaları (Dimensional Calculations)
    - Fiyat Hesaplamaları (Price Calculations)
    - Stok Hesaplamaları (Stock Calculations)
  
  4. Notes
    - All calculations will now be fully dynamic
    - Admin can update any value and changes apply immediately
    - No code changes needed for future adjustments
*/

-- Add category column to calculation_variables if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'calculation_variables' AND column_name = 'category'
  ) THEN
    ALTER TABLE calculation_variables ADD COLUMN category text DEFAULT 'Genel';
  END IF;
END $$;

-- Update existing variables with categories
UPDATE calculation_variables 
SET category = 'Ölçü Hesaplamaları'
WHERE variable_name IN ('kayit_genisligi', 'profil_binme_payi', 'uzunluk_payi', 'kayit_profil_payi', 'panel_uzunluk_payi');

-- Insert new calculation variables
INSERT INTO calculation_variables (variable_name, value, description, unit, category) VALUES
  ('kdv_orani', 0.20, 'KDV Oranı (%20)', '%', 'Fiyat Hesaplamaları'),
  ('bacak_asagi_payi', 180, 'Bacak yüksekliği düşürme payı', 'mm', 'Ölçü Hesaplamaları'),
  ('fit_meter_carpani', 1000, 'Fit hesabı için metre çarpanı', 'adet/m', 'Aksesuar Hesaplamaları'),
  ('default_stock1', 6000, 'Varsayılan stok boyu 1', 'mm', 'Stok Hesaplamaları'),
  ('default_stock2', 5500, 'Varsayılan stok boyu 2', 'mm', 'Stok Hesaplamaları'),
  ('kayit_fit_carpani', 2, 'Kayıt profili için fit çarpanı', 'kat', 'Aksesuar Hesaplamaları'),
  ('duvar_kapagi_adet', 2, 'Duvar kapağı sabit adet', 'adet', 'Aksesuar Hesaplamaları'),
  ('oluk_kapagi_adet', 2, 'Oluk kapağı sabit adet', 'adet', 'Aksesuar Hesaplamaları')
ON CONFLICT (variable_name) DO UPDATE 
SET 
  description = EXCLUDED.description,
  category = EXCLUDED.category;