/*
  # Add Kayıt Profil Payı Variable

  1. Changes
    - Adds `kayit_profil_payi` variable to calculation_variables table with default value 155
  
  2. Purpose
    - This value is subtracted from the hip length calculation for L705 profile
    - Formula: L705 = hip - kayit_profil_payi
*/

INSERT INTO calculation_variables (variable_name, value, description)
VALUES ('kayit_profil_payi', 155, 'L705 kayıt profil payı (hipotenüsten çıkarılır)')
ON CONFLICT (variable_name) DO UPDATE 
SET value = EXCLUDED.value, description = EXCLUDED.description;
